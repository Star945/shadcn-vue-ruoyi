# shadcn-vue-ruoyi

基于 `Vue 3 + TypeScript + shadcn-vue + Tailwind CSS v4` 重构的若依后台前端，目标是保留 RuoYi-Vue3 的后台信息架构、真实接口链路和管理工作流，同时替换为更现代的组件体系与主题系统。

## 当前状态

- 已接入真实若依登录、`/getInfo`、菜单、权限和主要系统管理接口
- 核心页面已改为独立业务页，不再走统一配置渲染
- 支持动态主题、主题色、圆角半径和标签页操作
- 兼容若依常见旧路径与隐藏业务页路由

## 技术栈

- Vue 3
- TypeScript
- Vite 6
- Pinia
- Vue Router
- shadcn-vue
- Tailwind CSS v4
- Reka UI

## 本地开发

```bash
pnpm install
pnpm dev
```

默认通过 `vite` 代理将 `/dev-api` 转发到本地若依后端。开发地址可在 `.env.development` 中修改：

```env
VITE_APP_DEV_PROXY_TARGET=http://localhost:8080
```

## 打包

```bash
pnpm build
```

## 目录说明

- `src/views`：业务页面
- `src/api`：若依接口模块
- `src/components/admin`：后台通用业务组件
- `src/components/ui`：shadcn-vue 基础组件
- `src/router`：静态路由与后端路由兼容映射
- `src/theme`：主题预设与主题应用逻辑

## 注意事项

- 仓库中的 `_references` 和 `_scaffold` 仅作为历史参考，不参与运行。
- 开发态已在 `vite.config.ts` 中忽略这些目录监听，避免历史脚手架文件影响当前项目。