<script setup lang="ts">
import { RouterView } from 'vue-router'

import AppHeader from '@/components/app/AppHeader.vue'
import AppSidebar from '@/components/app/AppSidebar.vue'
import AppTagsView from '@/components/app/AppTagsView.vue'
import { SidebarInset, SidebarProvider } from '@/components/ui/sidebar'
</script>

<template>
  <SidebarProvider class="[--sidebar-width:18rem] [--sidebar-width-icon:4.25rem]">
    <AppSidebar />
    <SidebarInset class="overflow-hidden bg-transparent">
      <div class="relative min-h-svh">
        <div class="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_right,var(--surface-glow-primary),transparent_35%),radial-gradient(circle_at_left_center,var(--surface-glow-secondary),transparent_30%),linear-gradient(180deg,var(--layout-surface-start),var(--layout-surface-end))]" />
        <div class="relative flex min-h-svh flex-col">
          <AppHeader />
          <AppTagsView />
          <main class="mx-auto flex w-full max-w-[1600px] flex-1 flex-col px-4 pb-6 pt-6 md:px-6">
            <RouterView v-slot="{ Component, route }">
              <Transition name="page" mode="out-in">
                <component :is="Component" :key="route.fullPath" />
              </Transition>
            </RouterView>
          </main>
        </div>
      </div>
    </SidebarInset>
  </SidebarProvider>
</template>
