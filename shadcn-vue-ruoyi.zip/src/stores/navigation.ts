﻿import type { IconName } from '@/lib/icons'

import { defineStore } from 'pinia'

import { getRouters } from '@/api/menu'
import { canonicalizeBackendRoutePath, resolveCanonicalBackendRoutePath, resolveRawBackendRoutePath } from '@/router/backend-route-map'

export interface NavigationItem {
  title: string
  path: string
  icon: IconName
}

export interface NavigationGroup {
  title: string
  items: NavigationItem[]
}

interface BackendRoute {
  path?: string
  hidden?: boolean
  component?: string
  alwaysShow?: boolean
  redirect?: string
  children?: BackendRoute[]
  meta?: {
    title?: string
    icon?: string
    noCache?: boolean
    link?: string
  }
}

interface NavigationState {
  groups: NavigationGroup[]
  quickActions: NavigationItem[]
  titleMap: Record<string, string>
  loaded: boolean
  loading: boolean
}

const fallbackGroups: NavigationGroup[] = [
  {
    title: '工作台',
    items: [{ title: '工作台', path: '/index', icon: 'layout-dashboard' }],
  },
  {
    title: '系统管理',
    items: [
      { title: '用户管理', path: '/system/user', icon: 'users' },
      { title: '角色管理', path: '/system/role', icon: 'shield' },
      { title: '菜单管理', path: '/system/menu', icon: 'folder-tree' },
      { title: '部门管理', path: '/system/dept', icon: 'network' },
      { title: '岗位管理', path: '/system/post', icon: 'briefcase' },
      { title: '字典管理', path: '/system/dict', icon: 'book' },
      { title: '参数设置', path: '/system/config', icon: 'sliders' },
      { title: '通知公告', path: '/system/notice', icon: 'bell' },
    ],
  },
  {
    title: '系统监控',
    items: [
      { title: '在线用户', path: '/monitor/online', icon: 'users' },
      { title: '定时任务', path: '/monitor/job', icon: 'timer' },
      { title: '登录日志', path: '/monitor/logininfor', icon: 'logs' },
      { title: '操作日志', path: '/monitor/operlog', icon: 'shield-ellipsis' },
      { title: '服务监控', path: '/monitor/server', icon: 'server' },
      { title: '缓存监控', path: '/monitor/cache', icon: 'database' },
      { title: 'Druid 监控', path: '/monitor/druid', icon: 'monitor-cog' },
    ],
  },
  {
    title: '系统工具',
    items: [
      { title: '表单构建', path: '/tool/build', icon: 'palette' },
      { title: '代码生成', path: '/tool/gen', icon: 'code' },
      { title: '接口文档', path: '/tool/swagger', icon: 'swagger' },
    ],
  },
]

const quickActions: NavigationItem[] = [
  { title: '个人中心', path: '/user/profile', icon: 'user' },
  { title: '锁屏', path: '/lock', icon: 'lock' },
]

const quickActionGroupTitle = '快捷入口'
const groupOrder = ['工作台', '系统管理', '系统监控', '系统工具', '其他菜单']

function matchesPathOrChild(path: string, target: string) {
  const normalizedPath = canonicalizePath(path)
  const normalizedTarget = canonicalizePath(target)
  return normalizedPath === normalizedTarget || normalizedPath.startsWith(`${normalizedTarget}/`)
}

const iconAliases: Record<string, IconName> = {
  dashboard: 'layout-dashboard',
  monitor: 'monitor-cog',
  tool: 'app-window',
  system: 'sliders',
  peoples: 'users',
  user: 'user',
  role: 'shield',
  tree: 'folder-tree',
  treeTable: 'folder-tree',
  dept: 'network',
  post: 'briefcase',
  dict: 'book',
  edit: 'sliders',
  message: 'bell',
  online: 'users',
  job: 'timer',
  log: 'logs',
  form: 'palette',
  build: 'palette',
  code: 'code',
  swagger: 'swagger',
  redis: 'database',
  druid: 'monitor-cog',
  server: 'server',
}

function canonicalizePath(path: string) {
  return canonicalizeBackendRoutePath(path)
}

function resolveRawPath(parentPath: string, path?: string) {
  return resolveRawBackendRoutePath(parentPath, path)
}

function resolvePath(parentPath: string, path?: string, component?: string) {
  return resolveCanonicalBackendRoutePath(path, component, parentPath)
}

function titleOf(route: BackendRoute) {
  return String(route.meta?.title ?? '').trim()
}

function iconFromPath(path: string): IconName {
  if (path === '/index') return 'layout-dashboard'
  if (path.startsWith('/system/user')) return 'users'
  if (path.startsWith('/system/role')) return 'shield'
  if (path.startsWith('/system/menu')) return 'folder-tree'
  if (path.startsWith('/system/dept')) return 'network'
  if (path.startsWith('/system/post')) return 'briefcase'
  if (path.startsWith('/system/dict')) return 'book'
  if (path.startsWith('/system/config')) return 'sliders'
  if (path.startsWith('/system/notice')) return 'bell'
  if (path.startsWith('/monitor/job')) return 'timer'
  if (path.startsWith('/monitor/server')) return 'server'
  if (path.startsWith('/monitor/cache')) return 'database'
  if (path.startsWith('/monitor')) return 'monitor-cog'
  if (path.startsWith('/tool/build')) return 'palette'
  if (path.startsWith('/tool/gen')) return 'code'
  if (path.startsWith('/tool/swagger')) return 'swagger'
  return 'app-window'
}

function iconOf(route: BackendRoute, path: string): IconName {
  const raw = String(route.meta?.icon ?? '').trim()
  if (raw && raw in iconAliases) {
    return iconAliases[raw]
  }
  return iconFromPath(path)
}

function groupTitleOf(path: string) {
  if (path === '/index') return '工作台'
  if (path.startsWith('/system')) return '系统管理'
  if (path.startsWith('/monitor')) return '系统监控'
  if (path.startsWith('/tool')) return '系统工具'
  return '其他菜单'
}

function walkRoutes(
  routes: BackendRoute[],
  parentPath = '',
  items: NavigationItem[] = [],
  titleMap: Record<string, string> = {},
) {
  routes.forEach((route) => {
    const rawPath = resolveRawPath(parentPath, route.path)
    const path = resolvePath(parentPath, route.path, route.component)
    const title = titleOf(route)
    if (title) {
      titleMap[path] = title
      if (rawPath !== path) {
        titleMap[rawPath] = title
      }
    }

    const children = Array.isArray(route.children) ? route.children : []
    const isContainer = route.component === 'Layout' || route.component === 'ParentView' || children.length > 0
    const isVisible = !route.hidden && Boolean(title)

    if (isVisible && (!isContainer || path === '/index')) {
      items.push({ title, path, icon: iconOf(route, path) })
    }

    if (children.length) {
      walkRoutes(children, rawPath, items, titleMap)
    }
  })

  return { items, titleMap }
}

function buildGroups(routes: BackendRoute[]) {
  const { items, titleMap } = walkRoutes(routes)
  const grouped = new Map<string, NavigationItem[]>()

  items.forEach((item) => {
    const groupTitle = groupTitleOf(item.path)
    const current = grouped.get(groupTitle) ?? []
    current.push(item)
    grouped.set(groupTitle, current)
  })

  const groups = groupOrder
    .filter(title => grouped.has(title))
    .map(title => ({
      title,
      items: (grouped.get(title) ?? []).sort((left, right) => left.path.localeCompare(right.path, 'zh-CN')),
    }))

  if (!groups.length) {
    return {
      groups: fallbackGroups,
      titleMap: fallbackGroups.flatMap(group => group.items).reduce<Record<string, string>>((map, item) => {
        map[item.path] = item.title
        return map
      }, {}),
    }
  }

  return { groups, titleMap }
}

export const useNavigationStore = defineStore('navigation', {
  state: (): NavigationState => ({
    groups: fallbackGroups,
    quickActions,
    titleMap: fallbackGroups.flatMap(group => group.items).reduce<Record<string, string>>((map, item) => {
      map[item.path] = item.title
      return map
    }, {
      '/user/profile': '个人中心',
      '/lock': '锁屏',
    }),
    loaded: false,
    loading: false,
  }),
  getters: {
    allItems(state) {
      return state.groups.flatMap(group => group.items)
    },
  },
  actions: {
    async ensureLoaded(force = false) {
      if (this.loading || (this.loaded && !force)) {
        return
      }
      this.loading = true
      try {
        const response = await getRouters()
        const backendRoutes = Array.isArray(response.data) ? response.data : []
        const built = buildGroups(backendRoutes)
        this.groups = built.groups
        this.titleMap = {
          ...this.titleMap,
          ...built.titleMap,
        }
        this.loaded = true
      }
      catch {
        this.groups = fallbackGroups
        this.loaded = true
      }
      finally {
        this.loading = false
      }
    },
    resolveTitle(path: string) {
      const normalized = canonicalizePath(path)
      return this.titleMap[normalized] ?? this.titleMap[path]
    },
    findGroup(path: string) {
      const normalized = canonicalizePath(path)
      const quickAction = this.quickActions.find(item => matchesPathOrChild(normalized, item.path))
      if (quickAction) {
        return {
          title: quickActionGroupTitle,
          items: this.quickActions,
        }
      }
      return this.groups.find(group => group.items.some(item => item.path === normalized))
    },
    findItem(path: string) {
      const normalized = canonicalizePath(path)
      return this.groups.flatMap(group => group.items).find(item => item.path === normalized)
        ?? this.quickActions.find(item => matchesPathOrChild(normalized, item.path))
    },
    canAccessRoute(path: string, activeMenu?: string) {
      const normalized = canonicalizePath(path)
      const normalizedActiveMenu = activeMenu ? canonicalizePath(activeMenu) : ''

      if (normalized === '/index') {
        return true
      }

      if (this.quickActions.some(item => matchesPathOrChild(normalized, item.path))) {
        return true
      }

      if (this.findItem(normalized)) {
        return true
      }

      if (normalizedActiveMenu && (this.findItem(normalizedActiveMenu) || this.quickActions.some(item => matchesPathOrChild(normalizedActiveMenu, item.path)))) {
        return true
      }

      return false
    },
  },
})





