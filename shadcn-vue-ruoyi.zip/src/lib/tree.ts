﻿export interface FlatTreeNode<T> {
  id: string
  label: string
  depth: number
  raw: T
}

export function flattenTree<T>(
  nodes: T[],
  options: {
    getId: (node: T) => string | number
    getLabel: (node: T) => string
    getChildren?: (node: T) => T[] | undefined
  },
  depth = 0,
): FlatTreeNode<T>[] {
  const getChildren = options.getChildren ?? ((node: T) => (node as { children?: T[] }).children)
  return nodes.flatMap((node) => {
    const current: FlatTreeNode<T> = {
      id: String(options.getId(node)),
      label: options.getLabel(node),
      depth,
      raw: node,
    }
    const children = getChildren(node) ?? []
    return [current, ...flattenTree(children, options, depth + 1)]
  })
}

export function buildDateRangeParams(beginTime?: string, endTime?: string) {
  return {
    ...(beginTime ? { 'params[beginTime]': beginTime } : {}),
    ...(endTime ? { 'params[endTime]': endTime } : {}),
  }
}

export function toArray<T>(value: T | T[] | null | undefined) {
  if (Array.isArray(value)) {
    return value
  }
  return value === undefined || value === null ? [] : [value]
}
