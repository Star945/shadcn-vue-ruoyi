<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute } from 'vue-router'
import { toast } from 'vue-sonner'

import { getUserProfile, updateUserProfile, updateUserPwd, uploadAvatar } from '@/api/system/user'
import AdminFormField from '@/components/admin/AdminFormField.vue'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { useSessionStore } from '@/stores/session'

const route = useRoute()
const session = useSessionStore()

const loading = ref(false)
const savingProfile = ref(false)
const savingPassword = ref(false)
const uploadingAvatar = ref(false)
const activeTab = ref(route.params.activeTab === 'password' || route.query.tab === 'password' ? 'password' : 'profile')
const avatarUrl = ref('')
const roleGroup = ref('--')
const postGroup = ref('--')
const profile = ref<Record<string, any>>({})
const avatarInput = ref<HTMLInputElement | null>(null)

const profileForm = reactive({
  nickName: '',
  phonenumber: '',
  email: '',
  sex: '0',
})

const passwordForm = reactive({
  oldPassword: '',
  newPassword: '',
  confirmPassword: '',
})

const securityHints = computed(() => {
  const hints: string[] = []
  if (profile.value.isDefaultModifyPwd) {
    hints.push('当前仍在使用默认密码，建议尽快修改。')
  }
  if (profile.value.isPasswordExpired) {
    hints.push('当前密码已过期，请立即更新密码。')
  }
  return hints
})

const deptLabel = computed(() => {
  const deptName = String(profile.value.dept?.deptName ?? '')
  return [deptName, postGroup.value].filter(Boolean).join(' / ') || '--'
})

function resolveAvatarUrl(value: unknown) {
  const raw = String(value ?? '').trim()
  if (!raw) {
    return ''
  }
  if (raw.startsWith('http://') || raw.startsWith('https://') || raw.startsWith('data:') || raw.startsWith('blob:')) {
    return raw
  }
  const base = String(import.meta.env.VITE_APP_BASE_API ?? '')
  if (!base) {
    return raw
  }
  if (raw.startsWith('/')) {
    return `${base}${raw}`
  }
  return `${base}/${raw}`
}

async function loadProfile() {
  loading.value = true
  try {
    const response = await getUserProfile()
    profile.value = {
      ...(response.data ?? {}),
      isDefaultModifyPwd: response.isDefaultModifyPwd ?? false,
      isPasswordExpired: response.isPasswordExpired ?? false,
    }
    roleGroup.value = String(response.roleGroup ?? '--') || '--'
    postGroup.value = String(response.postGroup ?? '--') || '--'
    avatarUrl.value = resolveAvatarUrl(response.data?.avatar)
    profileForm.nickName = String(response.data?.nickName ?? '')
    profileForm.phonenumber = String(response.data?.phonenumber ?? '')
    profileForm.email = String(response.data?.email ?? '')
    profileForm.sex = String(response.data?.sex ?? '0')
  }
  catch (error) {
    toast.error('个人资料加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    loading.value = false
  }
}

function validateProfileForm() {
  if (!profileForm.nickName.trim()) {
    toast.warning('请输入用户昵称')
    return false
  }
  if (!/^1[3-9]\d{9}$/.test(profileForm.phonenumber)) {
    toast.warning('请输入正确的手机号码')
    return false
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profileForm.email)) {
    toast.warning('请输入正确的邮箱地址')
    return false
  }
  return true
}

async function submitProfile() {
  if (!validateProfileForm()) {
    return
  }

  savingProfile.value = true
  try {
    await updateUserProfile({ ...profileForm })
    toast.success('个人资料修改成功')
    await Promise.all([loadProfile(), session.fetchProfile()])
  }
  catch (error) {
    toast.error('个人资料修改失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    savingProfile.value = false
  }
}

function validatePasswordForm() {
  if (!passwordForm.oldPassword.trim()) {
    toast.warning('请输入旧密码')
    return false
  }
  if (passwordForm.newPassword.length < 6 || passwordForm.newPassword.length > 20) {
    toast.warning('新密码长度必须在 6 到 20 位之间')
    return false
  }
  if (!/^[^<>"'|\\]+$/.test(passwordForm.newPassword)) {
    toast.warning('新密码不能包含非法字符 < > " \' | \\')
    return false
  }
  if (passwordForm.newPassword !== passwordForm.confirmPassword) {
    toast.warning('两次输入的新密码不一致')
    return false
  }
  return true
}

async function submitPassword() {
  if (!validatePasswordForm()) {
    return
  }

  savingPassword.value = true
  try {
    await updateUserPwd(passwordForm.oldPassword, passwordForm.newPassword)
    toast.success('密码修改成功')
    passwordForm.oldPassword = ''
    passwordForm.newPassword = ''
    passwordForm.confirmPassword = ''
  }
  catch (error) {
    toast.error('密码修改失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    savingPassword.value = false
  }
}

function chooseAvatar() {
  avatarInput.value?.click()
}

async function handleAvatarChange(event: Event) {
  const input = event.target as HTMLInputElement
  const file = input.files?.[0]
  if (!file) {
    return
  }

  if (!file.type.startsWith('image/')) {
    toast.warning('请上传图片文件')
    input.value = ''
    return
  }

  uploadingAvatar.value = true
  try {
    const formData = new FormData()
    formData.append('avatarfile', file, file.name)
    const response = await uploadAvatar(formData) as { imgUrl?: string }
    if (response?.imgUrl) {
      avatarUrl.value = resolveAvatarUrl(response.imgUrl)
    }
    toast.success('头像上传成功')
    await Promise.all([loadProfile(), session.fetchProfile()])
  }
  catch (error) {
    toast.error('头像上传失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    input.value = ''
    uploadingAvatar.value = false
  }
}

onMounted(loadProfile)
</script>

<template>
  <div class="space-y-6">
    <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.24em] text-muted-foreground">系统管理 / 个人中心</p>
        <h1 class="mt-2 text-3xl font-semibold tracking-tight">个人中心</h1>
        <p class="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">个人中心已切成真实资料页，支持资料修改、密码更新和头像上传。</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <Button variant="outline" @click="loadProfile">刷新资料</Button>
      </div>
    </div>

    <div class="grid gap-6 xl:grid-cols-[340px_minmax(0,1fr)]">
      <AdminSectionCard title="个人信息" description="当前登录用户的基础资料与账号归属。">
        <div v-if="loading" class="text-sm text-muted-foreground">正在加载个人信息...</div>
        <div v-else class="space-y-5">
          <div class="flex flex-col items-center gap-4 text-center">
            <Avatar class="size-28 rounded-3xl border border-border/60 bg-muted/20">
              <AvatarImage v-if="avatarUrl" :src="avatarUrl" :alt="profile.nickName || profile.userName || '用户头像'" />
              <AvatarFallback class="rounded-3xl text-2xl font-semibold">{{ session.user.avatar || 'RY' }}</AvatarFallback>
            </Avatar>
            <div>
              <p class="text-lg font-semibold">{{ profile.nickName || profile.userName || session.user.name }}</p>
              <p class="mt-1 text-sm text-muted-foreground">{{ roleGroup }}</p>
            </div>
            <div class="flex flex-wrap justify-center gap-2">
              <Button variant="outline" :disabled="uploadingAvatar" @click="chooseAvatar">{{ uploadingAvatar ? '上传中...' : '上传头像' }}</Button>
              <input ref="avatarInput" accept="image/*" class="hidden" type="file" @change="handleAvatarChange" />
            </div>
          </div>

          <div class="grid gap-3">
            <div v-for="item in [
              { label: '登录账号', value: profile.userName || '--' },
              { label: '手机号码', value: profile.phonenumber || '--' },
              { label: '邮箱地址', value: profile.email || '--' },
              { label: '所属部门', value: deptLabel },
              { label: '所属角色', value: roleGroup },
              { label: '创建时间', value: profile.createTime || '--' },
            ]" :key="item.label" class="flex items-center justify-between gap-3 rounded-2xl border border-border/60 bg-muted/20 px-4 py-3">
              <span class="text-sm text-muted-foreground">{{ item.label }}</span>
              <span class="text-sm font-medium text-right">{{ item.value }}</span>
            </div>
          </div>

          <div v-if="securityHints.length" class="flex flex-wrap gap-2">
            <Badge v-for="hint in securityHints" :key="hint" variant="destructive">{{ hint }}</Badge>
          </div>
        </div>
      </AdminSectionCard>

      <Tabs v-model:model-value="activeTab" class="space-y-4">
        <TabsList class="w-fit bg-muted/50 p-1">
          <TabsTrigger value="profile">基础资料</TabsTrigger>
          <TabsTrigger value="password">修改密码</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" class="mt-0">
          <AdminSectionCard title="基础资料" description="更新昵称、手机号、邮箱和性别信息。">
            <div v-if="loading" class="text-sm text-muted-foreground">正在加载资料表单...</div>
            <div v-else class="grid gap-4 md:grid-cols-2">
              <AdminFormField label="用户昵称">
                <Input v-model="profileForm.nickName" placeholder="请输入用户昵称" />
              </AdminFormField>
              <AdminFormField label="手机号码">
                <Input v-model="profileForm.phonenumber" placeholder="请输入手机号码" />
              </AdminFormField>
              <AdminFormField label="邮箱地址">
                <Input v-model="profileForm.email" placeholder="请输入邮箱地址" />
              </AdminFormField>
              <AdminFormField label="性别">
                <Select v-model="profileForm.sex">
                  <SelectTrigger><SelectValue placeholder="请选择性别" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">男</SelectItem>
                    <SelectItem value="1">女</SelectItem>
                    <SelectItem value="2">未知</SelectItem>
                  </SelectContent>
                </Select>
              </AdminFormField>
            </div>
            <div class="mt-6 flex flex-wrap gap-2">
              <Button :disabled="savingProfile" @click="submitProfile">{{ savingProfile ? '保存中...' : '保存资料' }}</Button>
              <Button variant="outline" @click="loadProfile">重置</Button>
            </div>
          </AdminSectionCard>
        </TabsContent>

        <TabsContent value="password" class="mt-0">
          <AdminSectionCard title="修改密码" description="密码长度需在 6 到 20 位之间，且不能包含非法字符。">
            <div class="grid gap-4 md:grid-cols-2">
              <AdminFormField label="旧密码">
                <Input v-model="passwordForm.oldPassword" type="password" placeholder="请输入旧密码" />
              </AdminFormField>
              <div class="hidden md:block" />
              <AdminFormField label="新密码">
                <Input v-model="passwordForm.newPassword" type="password" placeholder="请输入新密码" />
              </AdminFormField>
              <AdminFormField label="确认密码">
                <Input v-model="passwordForm.confirmPassword" type="password" placeholder="请再次输入新密码" />
              </AdminFormField>
            </div>
            <div class="mt-6 flex flex-wrap gap-2">
              <Button :disabled="savingPassword" @click="submitPassword">{{ savingPassword ? '提交中...' : '更新密码' }}</Button>
              <Button variant="outline" @click="activeTab = 'profile'">返回资料</Button>
            </div>
          </AdminSectionCard>
        </TabsContent>
      </Tabs>
    </div>
  </div>
</template>


