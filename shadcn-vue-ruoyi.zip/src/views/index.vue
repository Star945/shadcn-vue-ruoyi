<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { toast } from 'vue-sonner'

import type { AdminTableColumn } from '@/components/admin/data-table'
import type { NavigationItem } from '@/stores/navigation'

import { list as listLogininfor } from '@/api/monitor/logininfor'
import { list as listOnline } from '@/api/monitor/online'
import { list as listOperlog } from '@/api/monitor/operlog'
import { getServer } from '@/api/monitor/server'
import { listJob } from '@/api/monitor/job'
import { listNoticeTop } from '@/api/system/notice'
import AdminDataTable from '@/components/admin/AdminDataTable.vue'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { resolveIcon } from '@/lib/icons'
import { monitorOperStatusLabel, monitorResultLabel } from '@/lib/monitor'
import { useNavigationStore } from '@/stores/navigation'

interface NoticeItem {
  noticeId: string | number
  noticeTitle: string
  noticeType: string
  createTime?: string
  isRead?: boolean
}

const copy = {
  eyebrow: '\u5de5\u4f5c\u53f0\u6982\u89c8',
  title: '\u5de5\u4f5c\u53f0',
  intro: '\u9996\u9875\u5df2\u5207\u6362\u4e3a\u771f\u5b9e\u63a5\u53e3\u770b\u677f\uff0c\u6307\u6807\u3001\u516c\u544a\u3001\u76d1\u63a7\u548c\u5feb\u6377\u5165\u53e3\u90fd\u76f4\u63a5\u6765\u81ea\u5f53\u524d\u82e5\u4f9d\u540e\u7aef\u3002',
  lastUpdated: '\u6700\u540e\u5237\u65b0',
  refresh: '\u5237\u65b0\u770b\u677f',
  enterSystem: '\u8fdb\u5165\u7cfb\u7edf\u7ba1\u7406',
  viewMonitor: '\u67e5\u770b\u8fd0\u884c\u76d1\u63a7',
  partialLoadFailed: '\u5de5\u4f5c\u53f0\u90e8\u5206\u6570\u636e\u52a0\u8f7d\u5931\u8d25',
  partialLoadSuffix: '\u52a0\u8f7d\u5931\u8d25\uff0c\u5176\u4f59\u533a\u57df\u5df2\u4f7f\u7528\u6700\u8fd1\u6210\u529f\u6570\u636e\u3002',
  refreshSuccess: '\u5de5\u4f5c\u53f0\u5df2\u5237\u65b0',
  separator: '\u3001',
  metricOnline: '\u5728\u7ebf\u4f1a\u8bdd',
  metricOnlineDetail: '\u5f53\u524d\u5728\u7ebf\u8d26\u53f7 ',
  metricOnlineBadge: '\u5b9e\u65f6',
  metricOnlineLink: '\u67e5\u770b\u4f1a\u8bdd',
  metricJob: '\u5b9a\u65f6\u4efb\u52a1',
  metricJobDetailPrefix: '\u6b63\u5e38 ',
  metricJobDetailSuffix: '\u505c\u7528 ',
  metricJobLink: '\u7ba1\u7406\u4efb\u52a1',
  metricNotice: '\u672a\u8bfb\u516c\u544a',
  metricNoticeDetail: '\u9876\u90e8\u901a\u77e5\u4e2d\u5fc3\u5df2\u540c\u6b65 ',
  metricNoticeLink: '\u67e5\u770b\u516c\u544a',
  metricServer: '\u0043\u0050\u0055 \u4f7f\u7528\u7387',
  metricServerDetail: '\u5185\u5b58\u4f7f\u7528\u7387 ',
  metricServerLink: '\u67e5\u770b\u76d1\u63a7',
  metricStableBadge: '\u7a33\u5b9a',
  metricAttentionBadge: '\u5173\u6ce8',
  metricEmptyBadge: '\u5df2\u63a5\u901a',
  quickLinksTitle: '\u5feb\u6377\u5165\u53e3',
  quickLinksDescription: '\u4f18\u5148\u5c55\u793a\u540e\u7aef\u5df2\u8fd4\u56de\u7684\u83dc\u5355\u9875\u9762\u3002',
  quickLinkFallback: '\u5df2\u63a5\u5165\u540e\u7aef\u8def\u7531\u548c\u6743\u9650\u4fe1\u606f\u3002',
  quickUser: '\u771f\u5b9e 增删改查\u3001\u91cd\u7f6e\u5bc6\u7801\u3001\u5206\u914d\u89d2\u8272\u3002',
  quickRole: '\u89d2\u8272\u6743\u9650\u3001\u6570\u636e\u8303\u56f4\u3001\u5206\u914d\u7528\u6237\u3002',
  quickMenu: '\u83dc\u5355\u6811\u8868\u3001\u6309\u94ae\u6743\u9650\u3001\u8def\u7531\u914d\u7f6e\u3002',
  quickJob: '\u8c03\u5ea6 增删改查\u3001\u542f\u505c\u3001\u6267\u884c\u4e00\u6b21\u3001\u5bfc\u51fa\u3002',
  quickServer: '\u5b9e\u65f6 CPU\u3001\u5185\u5b58\u3001JVM \u548c\u78c1\u76d8\u76d1\u63a7\u3002',
  quickGen: '\u5bfc\u5165\u8868\u3001\u9884\u89c8\u4ee3\u7801\u3001\u751f\u6210\u538b\u7f29\u5305\u3002',
  quickOpen: '\u8fdb\u5165',
  noticeBoardTitle: '\u901a\u77e5\u516c\u544a',
  noticeBoardDescription: '\u5c55\u793a\u82e5\u4f9d\u9876\u90e8\u516c\u544a\u63a5\u53e3\u7684\u6700\u65b0\u5185\u5bb9\u548c\u672a\u8bfb\u72b6\u6001\u3002',
  noticeBoardAction: '\u524d\u5f80\u516c\u544a\u7ba1\u7406',
  noticeLoading: '\u6b63\u5728\u52a0\u8f7d\u516c\u544a...',
  noticeEmpty: '\u6682\u65e0\u516c\u544a\u6570\u636e',
  noticeUnread: '\u672a\u8bfb',
  noticeTypeNotice: '\u901a\u77e5',
  noticeTypeBulletin: '\u516c\u544a',
  runtimeTitle: '\u8fd0\u884c\u6982\u89c8',
  runtimeDescription: '\u6765\u81ea\u670d\u52a1\u76d1\u63a7\u3001\u767b\u5f55\u65e5\u5fd7\u548c\u64cd\u4f5c\u65e5\u5fd7\u7684\u5f53\u524d\u5feb\u7167\u3002',
  serverHost: '\u670d\u52a1\u5668\u540d\u79f0',
  serverOs: '\u64cd\u4f5c\u7cfb\u7edf',
  serverCpu: '\u0043\u0050\u0055',
  serverCpuCore: '\u6838',
  serverMemory: '\u7cfb\u7edf\u5185\u5b58',
  serverJvm: 'JVM',
  serverRisk: '\u98ce\u9669\u63d0\u793a',
  loginFailedShort: '\u767b\u5f55\u5931\u8d25 ',
  operExceptionShort: '\u5f02\u5e38\u64cd\u4f5c ',
  loginActivityTitle: '\u6700\u8fd1\u767b\u5f55\u52a8\u6001',
  loginActivityDescription: '\u4ece\u767b\u5f55\u65e5\u5fd7\u63a5\u53e3\u62c9\u53d6\u6700\u65b0\u8bbf\u95ee\u8bb0\u5f55\u3002',
  operActivityTitle: '\u6700\u8fd1\u64cd\u4f5c\u65e5\u5fd7',
  operActivityDescription: '\u4ece\u64cd\u4f5c\u65e5\u5fd7\u63a5\u53e3\u62c9\u53d6\u6700\u65b0\u5ba1\u8ba1\u8bb0\u5f55\u3002',
  statusSuccess: '\u6210\u529f',
  statusFailure: '\u5931\u8d25',
  statusNormal: '\u6b63\u5e38',
  statusException: '\u5f02\u5e38',
  loginEmpty: '\u6682\u65e0\u767b\u5f55\u52a8\u6001',
  operEmpty: '\u6682\u65e0\u64cd\u4f5c\u65e5\u5fd7',
  loginLoading: '\u6b63\u5728\u52a0\u8f7d\u767b\u5f55\u52a8\u6001...',
  operLoading: '\u6b63\u5728\u52a0\u8f7d\u64cd\u4f5c\u65e5\u5fd7...',
  fieldUserName: '\u7528\u6237\u540d\u79f0',
  fieldIpaddr: '\u767b\u5f55\u5730\u5740',
  fieldLoginStatus: '\u767b\u5f55\u72b6\u6001',
  fieldLoginTime: '\u767b\u5f55\u65f6\u95f4',
  fieldModule: '\u7cfb\u7edf\u6a21\u5757',
  fieldOperName: '\u64cd\u4f5c\u4eba\u5458',
  fieldOperStatus: '\u72b6\u6001',
  fieldOperTime: '\u64cd\u4f5c\u65f6\u95f4',
} as const

const loginColumns: AdminTableColumn[] = [
  { key: 'userName', title: copy.fieldUserName },
  { key: 'ipaddr', title: copy.fieldIpaddr },
  { key: 'status', title: copy.fieldLoginStatus, headerClass: 'text-center', cellClass: 'text-center' },
  { key: 'loginTime', title: copy.fieldLoginTime },
]

const operColumns: AdminTableColumn[] = [
  { key: 'title', title: copy.fieldModule },
  { key: 'operName', title: copy.fieldOperName },
  { key: 'status', title: copy.fieldOperStatus, headerClass: 'text-center', cellClass: 'text-center' },
  { key: 'operTime', title: copy.fieldOperTime },
]

const preferredQuickLinkPaths = [
  '/system/user',
  '/system/role',
  '/system/menu',
  '/monitor/job',
  '/monitor/server',
  '/tool/gen',
]

const quickLinkDescriptions: Record<string, string> = {
  '/system/user': copy.quickUser,
  '/system/role': copy.quickRole,
  '/system/menu': copy.quickMenu,
  '/monitor/job': copy.quickJob,
  '/monitor/server': copy.quickServer,
  '/tool/gen': copy.quickGen,
}

const navigation = useNavigationStore()

const loading = ref(false)
const onlineTotal = ref(0)
const jobTotal = ref(0)
const jobEnabledTotal = ref(0)
const unreadNoticeTotal = ref(0)
const notices = ref<NoticeItem[]>([])
const loginRows = ref<Record<string, any>[]>([])
const operRows = ref<Record<string, any>[]>([])
const server = ref<Record<string, any>>({})
const lastUpdated = ref('')

function normalizeNotice(item: Record<string, any>): NoticeItem {
  return {
    noticeId: item.noticeId,
    noticeTitle: String(item.noticeTitle ?? '--'),
    noticeType: String(item.noticeType ?? '1'),
    createTime: String(item.createTime ?? ''),
    isRead: Boolean(item.isRead),
  }
}

function toNumber(value: unknown, fallback = 0) {
  const numeric = Number(value)
  return Number.isFinite(numeric) ? numeric : fallback
}

function formatCount(value: unknown) {
  const numeric = Number(value)
  if (!Number.isFinite(numeric)) {
    return '--'
  }
  return new Intl.NumberFormat('zh-CN').format(numeric)
}

function formatPercent(value: unknown) {
  const numeric = Number(value)
  return Number.isFinite(numeric) ? `${numeric}%` : '--'
}

function formatUnit(value: unknown, unit: string) {
  const numeric = Number(value)
  return Number.isFinite(numeric) ? `${numeric}${unit}` : '--'
}

function noticeTypeText(value: string) {
  return value === '1' ? copy.noticeTypeNotice : copy.noticeTypeBulletin
}

function noticeTypeVariant(value: string) {
  return value === '1' ? 'secondary' : 'outline'
}

function metricVariant(value: string) {
  if (value === 'destructive') {
    return 'destructive'
  }
  if (value === 'secondary') {
    return 'secondary'
  }
  return 'outline'
}

function formatTimeStamp() {
  return new Date().toLocaleString('zh-CN', { hour12: false })
}

function quickLinkDescription(path: string) {
  return quickLinkDescriptions[path] ?? copy.quickLinkFallback
}

const recentNotices = computed(() => notices.value.slice(0, 5))

const quickLinks = computed(() => {
  const allItems = navigation.allItems.filter(item => item.path !== '/index')
  const itemMap = new Map(allItems.map(item => [item.path, item]))
  const ordered = [
    ...preferredQuickLinkPaths.map(path => itemMap.get(path)),
    ...allItems,
  ]

  const seen = new Set<string>()
  return ordered.filter((item): item is NavigationItem => {
    if (!item || seen.has(item.path)) {
      return false
    }
    seen.add(item.path)
    return true
  }).slice(0, 6)
})

const loginFailedCount = computed(() => loginRows.value.filter(item => String(item.status) === '1').length)
const operExceptionCount = computed(() => operRows.value.filter(item => String(item.status) === '1').length)

const metricCards = computed(() => {
  const pausedJobs = Math.max(jobTotal.value - jobEnabledTotal.value, 0)
  const cpuUsed = toNumber(server.value.cpu?.used)
  const memUsage = formatPercent(server.value.mem?.usage)

  return [
    {
      key: 'online',
      label: copy.metricOnline,
      value: formatCount(onlineTotal.value),
      detail: `${copy.metricOnlineDetail}${formatCount(onlineTotal.value)}`,
      badge: copy.metricOnlineBadge,
      tone: 'outline',
      path: '/monitor/online',
      linkText: copy.metricOnlineLink,
    },
    {
      key: 'job',
      label: copy.metricJob,
      value: formatCount(jobTotal.value),
      detail: `${copy.metricJobDetailPrefix}${formatCount(jobEnabledTotal.value)} / ${copy.metricJobDetailSuffix}${formatCount(pausedJobs)}`,
      badge: jobTotal.value ? copy.metricStableBadge : copy.metricEmptyBadge,
      tone: jobTotal.value ? 'secondary' : 'outline',
      path: '/monitor/job',
      linkText: copy.metricJobLink,
    },
    {
      key: 'notice',
      label: copy.metricNotice,
      value: formatCount(unreadNoticeTotal.value),
      detail: `${copy.metricNoticeDetail}${formatCount(notices.value.length)}`,
      badge: unreadNoticeTotal.value ? copy.metricAttentionBadge : copy.metricStableBadge,
      tone: unreadNoticeTotal.value ? 'destructive' : 'outline',
      path: '/system/notice',
      linkText: copy.metricNoticeLink,
    },
    {
      key: 'server',
      label: copy.metricServer,
      value: formatPercent(server.value.cpu?.used),
      detail: `${copy.metricServerDetail}${memUsage}`,
      badge: cpuUsed > 80 ? copy.metricAttentionBadge : copy.metricStableBadge,
      tone: cpuUsed > 80 ? 'destructive' : 'outline',
      path: '/monitor/server',
      linkText: copy.metricServerLink,
    },
  ]
})

const runtimeItems = computed(() => [
  { label: copy.serverHost, value: server.value.sys?.computerName || '--' },
  { label: copy.serverOs, value: server.value.sys?.osName || '--' },
  { label: copy.serverCpu, value: `${formatPercent(server.value.cpu?.used)} / ${copy.serverCpuCore}${formatCount(server.value.cpu?.cpuNum)}` },
  { label: copy.serverMemory, value: `${formatPercent(server.value.mem?.usage)} / ${formatUnit(server.value.mem?.used, 'G')} / ${formatUnit(server.value.mem?.total, 'G')}` },
  { label: copy.serverJvm, value: `${formatPercent(server.value.jvm?.usage)} / ${formatUnit(server.value.jvm?.used, 'M')} / ${formatUnit(server.value.jvm?.total, 'M')}` },
  { label: copy.serverRisk, value: `${copy.loginFailedShort}${formatCount(loginFailedCount.value)} / ${copy.operExceptionShort}${formatCount(operExceptionCount.value)}` },
])

async function loadDashboard(silent = false) {
  loading.value = true
  const navigationTask = navigation.ensureLoaded()
  const sections = [
    { key: 'notice', label: copy.noticeBoardTitle, task: listNoticeTop() },
    { key: 'online', label: copy.metricOnline, task: listOnline() },
    { key: 'jobAll', label: copy.metricJob, task: listJob({ pageNum: 1, pageSize: 1 }) },
    { key: 'jobEnabled', label: copy.metricJob, task: listJob({ pageNum: 1, pageSize: 1, status: '0' }) },
    { key: 'server', label: copy.runtimeTitle, task: getServer() },
    { key: 'login', label: copy.loginActivityTitle, task: listLogininfor({ pageNum: 1, pageSize: 6 }) },
    { key: 'oper', label: copy.operActivityTitle, task: listOperlog({ pageNum: 1, pageSize: 6 }) },
  ] as const

  try {
    const results = await Promise.allSettled(sections.map(item => item.task))
    const failedLabels: string[] = []

    results.forEach((result, index) => {
      const key = sections[index].key
      if (result.status !== 'fulfilled') {
        failedLabels.push(sections[index].label)
        return
      }

      const value: any = result.value
      switch (key) {
        case 'notice': {
          const rows = Array.isArray(value.data) ? value.data.map((item: any) => normalizeNotice(item)) : []
          notices.value = rows
          unreadNoticeTotal.value = typeof value.unreadCount === 'number'
            ? value.unreadCount
            : rows.filter((item: NoticeItem) => !item.isRead).length
          break
        }
        case 'online': {
          const rows = Array.isArray(value.rows) ? value.rows : []
          onlineTotal.value = toNumber(value.total, rows.length)
          break
        }
        case 'jobAll': {
          jobTotal.value = toNumber(value.total)
          break
        }
        case 'jobEnabled': {
          jobEnabledTotal.value = toNumber(value.total)
          break
        }
        case 'server': {
          server.value = value.data ?? {}
          break
        }
        case 'login': {
          loginRows.value = Array.isArray(value.rows) ? value.rows : []
          break
        }
        case 'oper': {
          operRows.value = Array.isArray(value.rows) ? value.rows : []
          break
        }
      }
    })

    await navigationTask
    lastUpdated.value = formatTimeStamp()

    if (failedLabels.length) {
      if (!silent) {
        toast.error(copy.partialLoadFailed, {
          description: `${failedLabels.join(copy.separator)}${copy.partialLoadSuffix}`,
        })
      }
      return
    }

    if (!silent) {
      toast.success(copy.refreshSuccess)
    }
  }
  finally {
    loading.value = false
  }
}

onMounted(() => {
  loadDashboard(true)
})
</script>

<template>
  <div class="space-y-6">
    <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.24em] text-muted-foreground">{{ copy.eyebrow }}</p>
        <h1 class="mt-2 text-3xl font-semibold tracking-tight">{{ copy.title }}</h1>
        <p class="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">{{ copy.intro }}</p>
        <p class="mt-2 text-xs text-muted-foreground">{{ copy.lastUpdated }} {{ lastUpdated || '--' }}</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <Button variant="outline" :disabled="loading" @click="loadDashboard()">{{ copy.refresh }}</Button>
        <Button as-child><RouterLink to="/system/user">{{ copy.enterSystem }}</RouterLink></Button>
        <Button as-child variant="outline"><RouterLink to="/monitor/server">{{ copy.viewMonitor }}</RouterLink></Button>
      </div>
    </div>

    <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
      <Card
        v-for="(metric, index) in metricCards"
        :key="metric.key"
        class="group animate-in fade-in slide-in-from-bottom-2 border-white/60 bg-white/75 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl dark:border-white/10 dark:bg-white/5"
        :style="{ animationDelay: `${index * 50}ms`, animationFillMode: 'both' }"
      >
        <CardHeader class="pb-3">
          <div class="flex items-center justify-between gap-3">
            <CardTitle class="text-sm font-medium text-muted-foreground">{{ metric.label }}</CardTitle>
            <Badge :variant="metricVariant(metric.tone)">{{ metric.badge }}</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div class="space-y-3">
            <div>
              <p class="text-3xl font-semibold tracking-tight">{{ metric.value }}</p>
              <p class="mt-2 text-sm text-muted-foreground">{{ metric.detail }}</p>
            </div>
            <div>
              <Button as-child variant="ghost" size="sm" class="-ml-2 px-2">
                <RouterLink :to="metric.path">{{ metric.linkText }}</RouterLink>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>

    <div class="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
      <AdminSectionCard :title="copy.noticeBoardTitle" :description="copy.noticeBoardDescription">
        <template #headerExtra>
          <Button as-child variant="outline" size="sm"><RouterLink to="/system/notice">{{ copy.noticeBoardAction }}</RouterLink></Button>
        </template>

        <div v-if="loading && !recentNotices.length" class="text-sm text-muted-foreground">{{ copy.noticeLoading }}</div>
        <div v-else-if="!recentNotices.length" class="text-sm text-muted-foreground">{{ copy.noticeEmpty }}</div>
        <div v-else class="grid gap-3">
          <div
            v-for="item in recentNotices"
            :key="item.noticeId"
            class="rounded-3xl border px-4 py-4"
            :class="item.isRead ? 'border-border/60 bg-muted/15' : 'border-primary/20 bg-primary/5'"
          >
            <div class="flex items-start justify-between gap-4">
              <div class="min-w-0 flex-1">
                <div class="flex flex-wrap items-center gap-2">
                  <Badge :variant="noticeTypeVariant(item.noticeType)">{{ noticeTypeText(item.noticeType) }}</Badge>
                  <span v-if="!item.isRead" class="text-xs font-medium text-primary">{{ copy.noticeUnread }}</span>
                </div>
                <p class="mt-3 truncate text-sm font-semibold">{{ item.noticeTitle }}</p>
                <p class="mt-1 text-xs text-muted-foreground">{{ item.createTime || '--' }}</p>
              </div>
            </div>
          </div>
        </div>
      </AdminSectionCard>

      <div class="grid gap-6">
        <AdminSectionCard :title="copy.quickLinksTitle" :description="copy.quickLinksDescription">
          <div class="grid gap-3">
            <RouterLink
              v-for="item in quickLinks"
              :key="item.path"
              :to="item.path"
              class="rounded-3xl border border-border/60 bg-muted/20 px-4 py-4 transition hover:border-border hover:bg-muted/35"
            >
              <div class="flex items-start gap-3">
                <div class="mt-0.5 flex size-10 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                  <component :is="resolveIcon(item.icon)" class="size-4" />
                </div>
                <div class="min-w-0 flex-1">
                  <div class="flex items-center justify-between gap-3">
                    <p class="text-sm font-semibold">{{ item.title }}</p>
                    <Badge variant="outline">{{ copy.quickOpen }}</Badge>
                  </div>
                  <p class="mt-1 text-sm leading-6 text-muted-foreground">{{ quickLinkDescription(item.path) }}</p>
                </div>
              </div>
            </RouterLink>
          </div>
        </AdminSectionCard>

        <AdminSectionCard :title="copy.runtimeTitle" :description="copy.runtimeDescription">
          <div class="grid gap-3">
            <div v-for="item in runtimeItems" :key="item.label" class="rounded-3xl border border-border/60 bg-muted/20 px-4 py-4">
              <p class="text-sm text-muted-foreground">{{ item.label }}</p>
              <p class="mt-2 text-sm font-semibold leading-6">{{ item.value }}</p>
            </div>
          </div>
        </AdminSectionCard>
      </div>
    </div>

    <div class="grid gap-6 xl:grid-cols-2">
      <AdminSectionCard :title="copy.loginActivityTitle" :description="copy.loginActivityDescription">
        <AdminDataTable
          :columns="loginColumns"
          :rows="loginRows"
          row-key="infoId"
          :loading="loading"
          :loading-text="copy.loginLoading"
          :empty-text="copy.loginEmpty"
        >
          <template #cell-userName="{ value }">
            <span class="font-medium">{{ value || '--' }}</span>
          </template>
          <template #cell-status="{ row }">
            <Badge :variant="String(row.status) === '0' ? 'default' : 'destructive'">
              {{ monitorResultLabel(row.status) }}
            </Badge>
          </template>
        </AdminDataTable>
      </AdminSectionCard>

      <AdminSectionCard :title="copy.operActivityTitle" :description="copy.operActivityDescription">
        <AdminDataTable
          :columns="operColumns"
          :rows="operRows"
          row-key="operId"
          :loading="loading"
          :loading-text="copy.operLoading"
          :empty-text="copy.operEmpty"
        >
          <template #cell-title="{ value }">
            <span class="font-medium">{{ value || '--' }}</span>
          </template>
          <template #cell-status="{ row }">
            <Badge :variant="String(row.status) === '0' ? 'default' : 'destructive'">
              {{ monitorOperStatusLabel(row.status) }}
            </Badge>
          </template>
        </AdminDataTable>
      </AdminSectionCard>
    </div>
  </div>
</template>



