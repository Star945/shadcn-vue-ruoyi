﻿<script setup lang="ts">
import { computed } from 'vue'

import { getDruidFrameSrc } from '@/api/monitor/druid'
import AdminEmbedFrame from '@/components/admin/AdminEmbedFrame.vue'
import { useAccess } from '@/lib/access'
import { permissionKeys } from '@/lib/permission-keys'

const access = useAccess()
const druidPerms = permissionKeys.monitor.druid
const frameSrc = getDruidFrameSrc()

const hasScopedDruidPerms = computed(() => access.hasAnyPrefix(druidPerms.scope))
const canViewDruid = computed(() => !hasScopedDruidPerms.value || access.can(druidPerms.view))
</script>

<template>
  <AdminEmbedFrame
    section-label="系统监控 / Druid"
    title="Druid 监控"
    description="直接嵌入后端 Druid 面板，用于查看 SQL 连接池与数据库监控信息。"
    :src="frameSrc"
    :can-view="canViewDruid"
    :can-refresh="canViewDruid"
    :can-copy="canViewDruid"
    :can-open="canViewDruid"
    blocked-title="当前账号暂无 Druid 面板查看权限"
    blocked-description="后端已启用 Druid 细粒度权限控制，当前账号未获得查看权限。"
  />
</template>
