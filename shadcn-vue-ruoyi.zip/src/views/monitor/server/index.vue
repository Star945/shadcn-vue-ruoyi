<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { toast } from 'vue-sonner'

import type { AdminTableColumn } from '@/components/admin/data-table'

import { getServer } from '@/api/monitor/server'
import AdminDataTable from '@/components/admin/AdminDataTable.vue'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

const diskColumns: AdminTableColumn[] = [
  { key: 'dirName', title: '盘符路径' },
  { key: 'sysTypeName', title: '文件系统' },
  { key: 'typeName', title: '盘符类型' },
  { key: 'total', title: '总大小' },
  { key: 'free', title: '可用大小' },
  { key: 'used', title: '已用大小' },
  { key: 'usage', title: '已用百分比', headerClass: 'text-center', cellClass: 'text-center' },
]

const loading = ref(false)
const server = ref<Record<string, any>>({})

const cpuItems = computed(() => [
  { label: '核心数', value: server.value.cpu?.cpuNum ?? '--' },
  { label: '用户使用率', value: server.value.cpu?.used ? `${server.value.cpu.used}%` : '--' },
  { label: '系统使用率', value: server.value.cpu?.sys ? `${server.value.cpu.sys}%` : '--' },
  { label: '当前空闲率', value: server.value.cpu?.free ? `${server.value.cpu.free}%` : '--' },
])

const memoryItems = computed(() => [
  { label: '总内存', value: server.value.mem?.total ? `${server.value.mem.total}G` : '--' },
  { label: '已用内存', value: server.value.mem?.used ? `${server.value.mem.used}G` : '--' },
  { label: '剩余内存', value: server.value.mem?.free ? `${server.value.mem.free}G` : '--' },
  { label: '内存使用率', value: server.value.mem?.usage ? `${server.value.mem.usage}%` : '--' },
])

const jvmItems = computed(() => [
  { label: 'JVM 总内存', value: server.value.jvm?.total ? `${server.value.jvm.total}M` : '--' },
  { label: 'JVM 已用', value: server.value.jvm?.used ? `${server.value.jvm.used}M` : '--' },
  { label: 'JVM 剩余', value: server.value.jvm?.free ? `${server.value.jvm.free}M` : '--' },
  { label: 'JVM 使用率', value: server.value.jvm?.usage ? `${server.value.jvm.usage}%` : '--' },
])

const systemItems = computed(() => [
  { label: '服务器名称', value: server.value.sys?.computerName ?? '--' },
  { label: '服务器 IP', value: server.value.sys?.computerIp ?? '--' },
  { label: '操作系统', value: server.value.sys?.osName ?? '--' },
  { label: '系统架构', value: server.value.sys?.osArch ?? '--' },
])

const jvmDetailItems = computed(() => [
  { label: 'Java 名称', value: server.value.jvm?.name ?? '--' },
  { label: 'Java 版本', value: server.value.jvm?.version ?? '--' },
  { label: '启动时间', value: server.value.jvm?.startTime ?? '--' },
  { label: '运行时长', value: server.value.jvm?.runTime ?? '--' },
  { label: '安装路径', value: server.value.jvm?.home ?? '--' },
  { label: '项目路径', value: server.value.sys?.userDir ?? '--' },
  { label: '运行参数', value: server.value.jvm?.inputArgs ?? '--' },
])

const diskRows = computed(() => Array.isArray(server.value.sysFiles) ? server.value.sysFiles : [])

function usageVariant(value: unknown) {
  return Number(value ?? 0) > 80 ? 'destructive' : 'outline'
}

async function loadServer() {
  loading.value = true
  try {
    const response = await getServer()
    server.value = response.data ?? {}
  }
  catch (error) {
    toast.error('服务监控加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    loading.value = false
  }
}

onMounted(loadServer)
</script>

<template>
  <div class="space-y-6">
    <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.24em] text-muted-foreground">系统监控 / 服务监控</p>
        <h1 class="mt-2 text-3xl font-semibold tracking-tight">服务监控</h1>
        <p class="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">服务监控页已切成真实运行态面板，展示 CPU、内存、JVM、系统信息与磁盘使用情况。</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <Button variant="outline" @click="loadServer">刷新监控</Button>
      </div>
    </div>

    <div class="grid gap-4 xl:grid-cols-3">
      <Card class="border-white/60 bg-white/75 dark:border-white/10 dark:bg-white/5">
        <CardHeader><CardTitle>CPU</CardTitle></CardHeader>
        <CardContent class="grid gap-3">
          <div v-for="item in cpuItems" :key="item.label" class="flex items-center justify-between gap-3 rounded-2xl border border-border/60 bg-muted/20 px-4 py-3">
            <span class="text-sm text-muted-foreground">{{ item.label }}</span>
            <span class="text-sm font-medium">{{ item.value }}</span>
          </div>
        </CardContent>
      </Card>

      <Card class="border-white/60 bg-white/75 dark:border-white/10 dark:bg-white/5">
        <CardHeader><CardTitle>系统内存</CardTitle></CardHeader>
        <CardContent class="grid gap-3">
          <div v-for="item in memoryItems" :key="item.label" class="flex items-center justify-between gap-3 rounded-2xl border border-border/60 bg-muted/20 px-4 py-3">
            <span class="text-sm text-muted-foreground">{{ item.label }}</span>
            <span class="text-sm font-medium">{{ item.value }}</span>
          </div>
        </CardContent>
      </Card>

      <Card class="border-white/60 bg-white/75 dark:border-white/10 dark:bg-white/5">
        <CardHeader><CardTitle>JVM 内存</CardTitle></CardHeader>
        <CardContent class="grid gap-3">
          <div v-for="item in jvmItems" :key="item.label" class="flex items-center justify-between gap-3 rounded-2xl border border-border/60 bg-muted/20 px-4 py-3">
            <span class="text-sm text-muted-foreground">{{ item.label }}</span>
            <span class="text-sm font-medium">{{ item.value }}</span>
          </div>
        </CardContent>
      </Card>
    </div>

    <AdminSectionCard title="服务器信息" description="当前主机与系统运行环境。">
      <div v-if="loading" class="text-sm text-muted-foreground">正在加载服务器信息...</div>
      <div v-else class="grid gap-4 md:grid-cols-2">
        <div v-for="item in systemItems" :key="item.label" class="rounded-2xl border border-border/60 bg-muted/20 px-4 py-4">
          <p class="text-sm text-muted-foreground">{{ item.label }}</p>
          <p class="mt-2 text-base font-medium">{{ item.value }}</p>
        </div>
      </div>
    </AdminSectionCard>

    <AdminSectionCard title="Java 虚拟机" description="展示 JVM 版本、启动时间、运行参数与项目路径。">
      <div v-if="loading" class="text-sm text-muted-foreground">正在加载 JVM 信息...</div>
      <div v-else class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        <div v-for="item in jvmDetailItems" :key="item.label" class="rounded-2xl border border-border/60 bg-muted/20 px-4 py-4">
          <p class="text-sm text-muted-foreground">{{ item.label }}</p>
          <p class="mt-2 break-all text-sm font-medium">{{ item.value }}</p>
        </div>
      </div>
    </AdminSectionCard>

    <AdminSectionCard title="磁盘状态" description="实时磁盘使用情况，已用率超过 80% 会高亮提示。">
      <AdminDataTable
        :columns="diskColumns"
        :rows="diskRows"
        row-key="dirName"
        :loading="loading"
        loading-text="正在加载磁盘信息..."
        empty-text="暂无磁盘信息"
      >
        <template #cell-usage="{ value }">
          <Badge :variant="usageVariant(value)">{{ value ? `${value}%` : '--' }}</Badge>
        </template>
      </AdminDataTable>
    </AdminSectionCard>
  </div>
</template>

