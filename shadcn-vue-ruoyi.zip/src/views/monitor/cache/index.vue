<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { toast } from 'vue-sonner'

import type { AdminTableColumn } from '@/components/admin/data-table'

import { clearCacheAll, clearCacheKey, clearCacheName, getCache, getCacheValue, listCacheKey, listCacheName } from '@/api/monitor/cache'
import AdminDataTable from '@/components/admin/AdminDataTable.vue'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { useAccess } from '@/lib/access'
import { prettyJson } from '@/lib/monitor'
import { permissionKeys } from '@/lib/permission-keys'

interface CacheNameRow {
  rawName: string
  name: string
  remark: string
}

interface CacheKeyRow {
  rawKey: string
  key: string
}

const cacheNameColumns: AdminTableColumn[] = [
  { key: 'name', title: '缓存名称' },
  { key: 'remark', title: '备注' },
]

const cacheKeyColumns: AdminTableColumn[] = [
  { key: 'key', title: '缓存键' },
]

const access = useAccess()
const cachePerms = permissionKeys.monitor.cache

const loading = ref(false)
const cache = ref<Record<string, any>>({})
const cacheNameRows = ref<CacheNameRow[]>([])
const cacheKeyRows = ref<CacheKeyRow[]>([])
const selectedCacheName = ref('')
const selectedCacheKey = ref('')
const selectedCacheValue = ref<any>(null)
const keyLoading = ref(false)
const valueLoading = ref(false)

const selectedCacheNameLabel = computed(() => stripCacheName(selectedCacheName.value))
const selectedCacheKeyLabel = computed(() => stripCacheKey(selectedCacheKey.value, selectedCacheName.value))

const basicItems = computed(() => [
  { label: 'Redis 版本', value: cache.value.info?.redis_version ?? '--' },
  { label: '运行模式', value: cache.value.info?.redis_mode === 'standalone' ? '单机' : cache.value.info?.redis_mode ?? '--' },
  { label: '端口', value: cache.value.info?.tcp_port ?? '--' },
  { label: '客户端数', value: cache.value.info?.connected_clients ?? '--' },
  { label: '运行天数', value: cache.value.info?.uptime_in_days ?? '--' },
  { label: '使用内存', value: cache.value.info?.used_memory_human ?? '--' },
  { label: '内存配置', value: cache.value.info?.maxmemory_human ?? '--' },
  { label: 'Key 数量', value: cache.value.dbSize ?? cache.value.dbsize ?? '--' },
  { label: 'AOF 是否开启', value: String(cache.value.info?.aof_enabled) === '0' ? '否' : cache.value.info?.aof_enabled !== undefined ? '是' : '--' },
  { label: 'RDB 状态', value: cache.value.info?.rdb_last_bgsave_status ?? '--' },
  { label: '网络入口', value: cache.value.info?.instantaneous_input_kbps ? `${cache.value.info.instantaneous_input_kbps} kps` : '--' },
  { label: '网络出口', value: cache.value.info?.instantaneous_output_kbps ? `${cache.value.info.instantaneous_output_kbps} kps` : '--' },
])

const commandStats = computed(() => Array.isArray(cache.value.commandStats) ? cache.value.commandStats : [])
const selectedValueText = computed(() => prettyJson(selectedCacheValue.value))
const hasCacheScopedPermissions = computed(() => access.hasAnyPrefix('monitor:cache:'))
const canManageCache = computed(() => !hasCacheScopedPermissions.value || access.can(cachePerms.manage))
const cacheReadonlyNotice = computed(() => hasCacheScopedPermissions.value && !canManageCache.value
  ? '当前账号仅有缓存查看权限，清理操作已自动隐藏。'
  : '')

function stripCacheName(cacheName: string) {
  return cacheName.replace(/:$/, '')
}

function stripCacheKey(cacheKey: string, cacheName: string) {
  if (!cacheName) {
    return cacheKey
  }
  return cacheKey.startsWith(cacheName) ? cacheKey.slice(cacheName.length) || cacheKey : cacheKey
}

function normalizeCacheNameRow(item: unknown) {
  if (typeof item === 'string') {
    const rawName = item.trim()
    return rawName
      ? {
          rawName,
          name: stripCacheName(rawName),
          remark: '--',
        }
      : null
  }

  if (!item || typeof item !== 'object') {
    return null
  }

  const raw = item as Record<string, unknown>
  const rawName = String(raw.cacheName ?? raw.name ?? '').trim()
  if (!rawName) {
    return null
  }

  return {
    rawName,
    name: stripCacheName(rawName),
    remark: String(raw.remark ?? '--') || '--',
  } satisfies CacheNameRow
}

function normalizeCacheKeyRow(item: unknown, cacheName: string) {
  const rawKey = typeof item === 'string'
    ? item.trim()
    : item && typeof item === 'object'
      ? String((item as Record<string, unknown>).cacheKey ?? (item as Record<string, unknown>).key ?? '').trim()
      : ''

  if (!rawKey) {
    return null
  }

  return {
    rawKey,
    key: stripCacheKey(rawKey, cacheName),
  } satisfies CacheKeyRow
}

async function loadCacheKeys(cacheName: string, preserveKey = false) {
  keyLoading.value = true
  valueLoading.value = false
  selectedCacheName.value = cacheName
  try {
    const response = await listCacheKey(cacheName)
    cacheKeyRows.value = (Array.isArray(response.data) ? response.data : [])
      .map(item => normalizeCacheKeyRow(item, cacheName))
      .filter((item): item is CacheKeyRow => Boolean(item))

    const nextKey = preserveKey && selectedCacheKey.value && cacheKeyRows.value.some(item => item.rawKey === selectedCacheKey.value)
      ? selectedCacheKey.value
      : cacheKeyRows.value[0]?.rawKey ?? ''

    if (nextKey) {
      await loadCacheValue(cacheName, nextKey)
    }
    else {
      selectedCacheKey.value = ''
      selectedCacheValue.value = null
    }
  }
  catch (error) {
    cacheKeyRows.value = []
    selectedCacheKey.value = ''
    selectedCacheValue.value = null
    toast.error('缓存键加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    keyLoading.value = false
  }
}

async function loadCacheValue(cacheName: string, cacheKey: string) {
  valueLoading.value = true
  selectedCacheName.value = cacheName
  selectedCacheKey.value = cacheKey
  try {
    const response = await getCacheValue(cacheName, cacheKey)
    selectedCacheValue.value = response.data?.cacheValue ?? response.data
  }
  catch (error) {
    selectedCacheValue.value = null
    toast.error('缓存值加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    valueLoading.value = false
  }
}

async function refreshCacheState(preserveSelection = true) {
  loading.value = true
  try {
    const [cacheResponse, nameResponse] = await Promise.all([
      getCache(),
      listCacheName(),
    ])

    cache.value = cacheResponse.data ?? {}
    cacheNameRows.value = (Array.isArray(nameResponse.data) ? nameResponse.data : [])
      .map(item => normalizeCacheNameRow(item))
      .filter((item): item is CacheNameRow => Boolean(item))

    const nextName = preserveSelection && selectedCacheName.value && cacheNameRows.value.some(item => item.rawName === selectedCacheName.value)
      ? selectedCacheName.value
      : cacheNameRows.value[0]?.rawName ?? ''

    if (nextName) {
      await loadCacheKeys(nextName, preserveSelection)
    }
    else {
      selectedCacheName.value = ''
      selectedCacheKey.value = ''
      selectedCacheValue.value = null
      cacheKeyRows.value = []
    }
  }
  catch (error) {
    toast.error('缓存监控加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    loading.value = false
  }
}

function requireCacheManage(actionLabel: string) {
  if (!hasCacheScopedPermissions.value) {
    return true
  }
  return access.require(cachePerms.manage, actionLabel)
}

async function handleClearAll() {
  if (!requireCacheManage('清理缓存')) {
    return
  }
  try {
    await clearCacheAll()
    toast.success('全部缓存已清理')
    await refreshCacheState(false)
  }
  catch (error) {
    toast.error('全量清理失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function handleClearName(cacheName: string) {
  if (!requireCacheManage('按名称清理缓存')) {
    return
  }
  try {
    await clearCacheName(cacheName)
    toast.success(`已清理缓存 ${stripCacheName(cacheName)}`)
    await refreshCacheState(false)
  }
  catch (error) {
    toast.error('按名称清理失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function handleClearKey(cacheKey: string) {
  if (!requireCacheManage('按键清理缓存')) {
    return
  }
  try {
    await clearCacheKey(cacheKey)
    toast.success(`已清理键 ${stripCacheKey(cacheKey, selectedCacheName.value)}`)
    await refreshCacheState(true)
  }
  catch (error) {
    toast.error('按键清理失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

onMounted(() => refreshCacheState(false))
</script>

<template>
  <div class="space-y-6">
    <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.24em] text-muted-foreground">系统监控 / 缓存监控</p>
        <h1 class="mt-2 text-3xl font-semibold tracking-tight">缓存监控</h1>
        <p class="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">缓存监控页已切成真实缓存浏览器，支持查看缓存名称、键和值，并执行按键、按名称和全量清理。</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <Button variant="outline" @click="refreshCacheState(true)">刷新监控</Button>
        <Button v-if="canManageCache" variant="destructive" @click="handleClearAll">清理全部</Button>
      </div>
    </div>

    <div v-if="cacheReadonlyNotice" class="rounded-3xl border border-amber-300/60 bg-amber-50/80 px-5 py-4 text-sm text-amber-900 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-100">
      {{ cacheReadonlyNotice }}
    </div>

    <AdminSectionCard title="Redis 概览" description="当前 Redis 实例的版本、运行模式、连接数、内存和持久化状态。">
      <div v-if="loading" class="text-sm text-muted-foreground">正在加载缓存监控...</div>
      <div v-else class="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        <div v-for="item in basicItems" :key="item.label" class="rounded-2xl border border-border/60 bg-muted/20 px-4 py-4">
          <p class="text-sm text-muted-foreground">{{ item.label }}</p>
          <p class="mt-2 text-sm font-medium">{{ item.value }}</p>
        </div>
      </div>
    </AdminSectionCard>

    <AdminSectionCard v-if="commandStats.length" title="命令统计" description="后端返回的 Redis 命令调用统计。">
      <div class="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        <div v-for="item in commandStats" :key="item.name" class="rounded-2xl border border-border/60 bg-muted/20 px-4 py-4">
          <p class="text-sm text-muted-foreground">{{ item.name }}</p>
          <p class="mt-2 text-base font-semibold">{{ item.value }}</p>
        </div>
      </div>
    </AdminSectionCard>

    <div class="grid gap-6 xl:grid-cols-[360px_minmax(0,1fr)_minmax(0,1.2fr)]">
      <AdminSectionCard title="缓存名称" :description="selectedCacheName ? `当前：${selectedCacheNameLabel}` : '选择一个缓存名称查看键列表。'">
        <AdminDataTable
          :columns="cacheNameColumns"
          :rows="cacheNameRows"
          row-key="rawName"
          :loading="loading"
          loading-text="正在加载缓存名称..."
          empty-text="暂无缓存名称"
          show-actions
          action-header-class="w-[180px] text-right"
        >
          <template #cell-name="{ row }">
            <div class="flex items-center gap-2">
              <span class="font-medium">{{ row.name }}</span>
              <Badge v-if="row.rawName === selectedCacheName" variant="outline">当前</Badge>
            </div>
          </template>
          <template #actions="{ row }">
            <div class="flex justify-end gap-2">
              <Button size="sm" variant="outline" @click="loadCacheKeys(row.rawName)">查看键</Button>
              <Button v-if="canManageCache" size="sm" variant="destructive" @click="handleClearName(row.rawName)">清理</Button>
            </div>
          </template>
        </AdminDataTable>
      </AdminSectionCard>

      <AdminSectionCard title="缓存键" :description="selectedCacheKey ? `当前：${selectedCacheKeyLabel}` : '选择一个缓存键查看值详情。'">
        <AdminDataTable
          :columns="cacheKeyColumns"
          :rows="cacheKeyRows"
          row-key="rawKey"
          :loading="keyLoading"
          loading-text="正在加载缓存键..."
          empty-text="当前缓存名称下暂无键"
          show-actions
          action-header-class="w-[180px] text-right"
        >
          <template #cell-key="{ row }">
            <div class="flex items-center gap-2">
              <span class="break-all font-medium">{{ row.key }}</span>
              <Badge v-if="row.rawKey === selectedCacheKey" variant="outline">当前</Badge>
            </div>
          </template>
          <template #actions="{ row }">
            <div class="flex justify-end gap-2">
              <Button size="sm" variant="outline" @click="loadCacheValue(selectedCacheName, row.rawKey)">查看值</Button>
              <Button v-if="canManageCache" size="sm" variant="destructive" @click="handleClearKey(row.rawKey)">清理</Button>
            </div>
          </template>
        </AdminDataTable>
      </AdminSectionCard>

      <AdminSectionCard title="缓存值详情" :description="selectedCacheName && selectedCacheKey ? `${selectedCacheNameLabel} / ${selectedCacheKeyLabel}` : '从左侧选择缓存键查看内容。'">
        <div class="rounded-3xl border border-border/60 bg-muted/20 p-4">
          <pre class="min-h-[520px] overflow-x-auto whitespace-pre-wrap font-mono text-xs leading-6 text-foreground">{{ valueLoading ? '正在加载缓存值...' : selectedValueText }}</pre>
        </div>
      </AdminSectionCard>
    </div>
  </div>
</template>



