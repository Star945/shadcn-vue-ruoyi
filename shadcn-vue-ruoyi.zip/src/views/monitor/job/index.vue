<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRouter } from 'vue-router'
import { toast } from 'vue-sonner'

import type { AdminTableColumn } from '@/components/admin/data-table'

import { addJob, changeJobStatus, delJob, exportJob, getJob, listJob, runJob, updateJob } from '@/api/monitor/job'
import AdminDataTable from '@/components/admin/AdminDataTable.vue'
import AdminFormField from '@/components/admin/AdminFormField.vue'
import AdminQueryPanel from '@/components/admin/AdminQueryPanel.vue'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Textarea } from '@/components/ui/textarea'
import { useAccess } from '@/lib/access'
import { saveBlob } from '@/lib/download'
import { permissionKeys } from '@/lib/permission-keys'

const router = useRouter()
const access = useAccess()
const jobPerms = permissionKeys.monitor.job

const jobTableColumns: AdminTableColumn[] = [
  { key: 'jobId', title: '任务编号' },
  { key: 'jobName', title: '任务名称' },
  { key: 'jobGroup', title: '任务组名' },
  { key: 'invokeTarget', title: '调用目标' },
  { key: 'cronExpression', title: 'Cron 表达式' },
  { key: 'status', title: '状态', headerClass: 'text-center', cellClass: 'text-center' },
  { key: 'nextValidTime', title: '下次执行时间' },
]

const loading = ref(false)
const submitting = ref(false)
const rows = ref<any[]>([])
const total = ref(0)
const formOpen = ref(false)
const formTitle = ref('新增任务')

const queryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  jobName: '',
  jobGroup: '',
  status: 'all',
})

const form = reactive(defaultForm())

const canAddJob = computed(() => access.can(jobPerms.add))
const canEditJob = computed(() => access.can(jobPerms.edit))
const canRemoveJob = computed(() => access.can(jobPerms.remove))
const canRunJob = computed(() => access.can(jobPerms.changeStatus))
const canChangeJobStatus = computed(() => access.can(jobPerms.changeStatus))
const canQueryJobLog = computed(() => access.can(jobPerms.query))
const canExportJob = computed(() => access.can(jobPerms.export))
const showJobActions = computed(() => canEditJob.value || canRemoveJob.value || canRunJob.value || canQueryJobLog.value)

function defaultForm() {
  return {
    jobId: '',
    jobName: '',
    jobGroup: 'DEFAULT',
    invokeTarget: '',
    cronExpression: '',
    misfirePolicy: '3',
    concurrent: '1',
    status: '0',
    remark: '',
  }
}

function resetFormState() {
  Object.assign(form, defaultForm())
}

function statusText(value: string) {
  return value === '0' ? '正常' : '停用'
}

function buildQueryPayload() {
  return {
    jobName: queryParams.jobName || undefined,
    jobGroup: queryParams.jobGroup || undefined,
    status: queryParams.status === 'all' ? undefined : queryParams.status,
  }
}

async function loadList() {
  loading.value = true
  try {
    const response = await listJob({
      pageNum: queryParams.pageNum,
      pageSize: queryParams.pageSize,
      ...buildQueryPayload(),
    })
    rows.value = Array.isArray(response.rows) ? response.rows : []
    total.value = Number(response.total ?? 0)
  }
  catch (error) {
    toast.error('定时任务加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    loading.value = false
  }
}

async function handleQuery() {
  queryParams.pageNum = 1
  await loadList()
}

async function handleResetQuery() {
  queryParams.pageNum = 1
  queryParams.pageSize = 10
  queryParams.jobName = ''
  queryParams.jobGroup = ''
  queryParams.status = 'all'
  await loadList()
}

async function handleExport() {
  if (!access.require(jobPerms.export, '导出定时任务')) {
    return
  }

  try {
    const blob = await exportJob(buildQueryPayload())
    saveBlob(blob, 'job.xlsx')
    toast.success('定时任务已开始导出')
  }
  catch (error) {
    toast.error('定时任务导出失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

function openCreate() {
  if (!access.require(jobPerms.add, '新增定时任务')) {
    return
  }
  resetFormState()
  formTitle.value = '新增任务'
  formOpen.value = true
}

async function openEdit(row: Record<string, any>) {
  if (!access.require(jobPerms.edit, '修改定时任务')) {
    return
  }
  resetFormState()
  formTitle.value = '修改任务'
  try {
    const response = await getJob(row.jobId)
    Object.assign(form, defaultForm(), response.data ?? {}, {
      jobId: response.data?.jobId ? String(response.data.jobId) : '',
      jobGroup: String(response.data?.jobGroup ?? 'DEFAULT'),
      misfirePolicy: String(response.data?.misfirePolicy ?? '3'),
      concurrent: String(response.data?.concurrent ?? '1'),
      status: String(response.data?.status ?? '0'),
    })
    formOpen.value = true
  }
  catch (error) {
    toast.error('任务信息加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

function validateForm() {
  if (!form.jobName.trim()) {
    toast.warning('请输入任务名称')
    return false
  }
  if (!form.invokeTarget.trim()) {
    toast.warning('请输入调用目标')
    return false
  }
  if (!form.cronExpression.trim()) {
    toast.warning('请输入 Cron 表达式')
    return false
  }
  return true
}

async function submitForm() {
  const action = form.jobId ? jobPerms.edit : jobPerms.add
  const actionLabel = form.jobId ? '修改定时任务' : '新增定时任务'
  if (!access.require(action, actionLabel)) {
    return
  }
  if (!validateForm()) {
    return
  }

  submitting.value = true
  try {
    const payload = {
      ...form,
      jobId: form.jobId || undefined,
    }
    if (form.jobId) {
      await updateJob(payload)
      toast.success('任务修改成功')
    }
    else {
      await addJob(payload)
      toast.success('任务新增成功')
    }
    formOpen.value = false
    await loadList()
  }
  catch (error) {
    toast.error(form.jobId ? '任务修改失败' : '任务新增失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    submitting.value = false
  }
}

async function removeRow(row: Record<string, any>) {
  if (!access.require(jobPerms.remove, '删除定时任务')) {
    return
  }
  try {
    await delJob(row.jobId)
    toast.success('任务删除成功')
    await loadList()
  }
  catch (error) {
    toast.error('任务删除失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function toggleStatus(row: Record<string, any>, value: boolean) {
  if (!access.require(jobPerms.changeStatus, `${value ? '启用' : '停用'}定时任务`)) {
    return
  }
  const targetStatus = value ? '0' : '1'
  try {
    await changeJobStatus(row.jobId, targetStatus)
    row.status = targetStatus
    toast.success(`已${value ? '启用' : '停用'}任务 ${row.jobName}`)
  }
  catch (error) {
    toast.error('任务状态更新失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function executeOnce(row: Record<string, any>) {
  if (!access.require(jobPerms.changeStatus, '执行一次定时任务')) {
    return
  }
  try {
    await runJob(row.jobId, String(row.jobGroup))
    toast.success(`已触发任务 ${row.jobName}`)
  }
  catch (error) {
    toast.error('任务执行失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

function openLogs(row: Record<string, any>) {
  if (!access.require(jobPerms.query, '查看调度日志')) {
    return
  }
  router.push(`/monitor/job-log/index/${row.jobId}`)
}

async function changePage(step: number) {
  const nextPage = queryParams.pageNum + step
  if (nextPage < 1) {
    return
  }
  queryParams.pageNum = nextPage
  await loadList()
}

async function changePageSize(value: number) {
  queryParams.pageNum = 1
  queryParams.pageSize = value
  await loadList()
}

onMounted(loadList)
</script>

<template>
  <div class="space-y-6">
    <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.24em] text-muted-foreground">系统监控 / 定时任务</p>
        <h1 class="mt-2 text-3xl font-semibold tracking-tight">定时任务</h1>
        <p class="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">定时任务页已经切成真实调度 增删改查，支持启停、执行一次、导出和查看调度日志。</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <Button v-if="canAddJob" @click="openCreate">新增任务</Button>
        <Button v-if="canExportJob" variant="outline" @click="handleExport">导出任务</Button>
        <Button variant="outline" @click="loadList">刷新列表</Button>
      </div>
    </div>

    <AdminQueryPanel description="任务名称、任务组名和状态直接作用于真实调度接口。" @query="handleQuery" @reset="handleResetQuery">
      <AdminFormField label="任务名称">
        <Input v-model="queryParams.jobName" placeholder="请输入任务名称" />
      </AdminFormField>
      <AdminFormField label="任务组名">
        <Input v-model="queryParams.jobGroup" placeholder="请输入任务组名" />
      </AdminFormField>
      <AdminFormField label="状态">
        <Select v-model="queryParams.status">
          <SelectTrigger><SelectValue placeholder="请选择状态" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部</SelectItem>
            <SelectItem value="0">正常</SelectItem>
            <SelectItem value="1">停用</SelectItem>
          </SelectContent>
        </Select>
      </AdminFormField>
    </AdminQueryPanel>

    <AdminSectionCard title="任务列表" description="支持任务 增删改查、启停、执行一次、导出和日志查看。">
      <AdminDataTable
        :columns="jobTableColumns"
        :rows="rows"
        row-key="jobId"
        :loading="loading"
        loading-text="正在加载任务数据..."
        empty-text="暂无数据"
        :show-actions="showJobActions"
        action-header-class="w-[320px] text-right"
        :show-pagination="true"
        :total="total"
        :page-num="queryParams.pageNum"
        :page-size="queryParams.pageSize"
        @update:page-size="changePageSize"
        @previous="changePage(-1)"
        @next="changePage(1)"
      >
        <template #cell-jobName="{ value }">
          <span class="font-medium">{{ value }}</span>
        </template>
        <template #cell-status="{ row }">
          <div class="flex items-center justify-center gap-2">
            <Switch v-if="canChangeJobStatus" :model-value="String(row.status) === '0'" @update:model-value="(value) => toggleStatus(row, Boolean(value))" />
            <Badge variant="outline">{{ statusText(String(row.status)) }}</Badge>
          </div>
        </template>
        <template #actions="{ row }">
          <div class="flex flex-wrap justify-end gap-2">
            <Button v-if="canRunJob" size="sm" variant="outline" @click="executeOnce(row)">执行一次</Button>
            <Button v-if="canQueryJobLog" size="sm" variant="outline" @click="openLogs(row)">任务日志</Button>
            <Button v-if="canEditJob" size="sm" variant="outline" @click="openEdit(row)">修改</Button>
            <Button v-if="canRemoveJob" size="sm" variant="destructive" @click="removeRow(row)">删除</Button>
          </div>
        </template>
      </AdminDataTable>
    </AdminSectionCard>

    <Dialog v-model:open="formOpen">
      <DialogContent class="sm:max-w-[860px]">
        <DialogHeader>
          <DialogTitle>{{ formTitle }}</DialogTitle>
          <DialogDescription>调度任务表单直接提交给真实任务接口。</DialogDescription>
        </DialogHeader>

        <div class="grid gap-4 md:grid-cols-2">
          <AdminFormField label="任务名称">
            <Input v-model="form.jobName" placeholder="请输入任务名称" />
          </AdminFormField>
          <AdminFormField label="任务组名">
            <Input v-model="form.jobGroup" placeholder="请输入任务组名" />
          </AdminFormField>
          <AdminFormField label="调用目标" field-class="md:col-span-2">
            <Input v-model="form.invokeTarget" placeholder="请输入调用目标，例如 demoTask.demoParams('ry')" />
          </AdminFormField>
          <AdminFormField label="Cron 表达式">
            <Input v-model="form.cronExpression" placeholder="请输入 Cron 表达式" />
          </AdminFormField>
          <AdminFormField label="状态">
            <Select v-model="form.status">
              <SelectTrigger><SelectValue placeholder="请选择状态" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">正常</SelectItem>
                <SelectItem value="1">停用</SelectItem>
              </SelectContent>
            </Select>
          </AdminFormField>
          <AdminFormField label="错过执行策略">
            <Select v-model="form.misfirePolicy">
              <SelectTrigger><SelectValue placeholder="请选择策略" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="1">立即执行</SelectItem>
                <SelectItem value="2">执行一次</SelectItem>
                <SelectItem value="3">放弃执行</SelectItem>
              </SelectContent>
            </Select>
          </AdminFormField>
          <AdminFormField label="并发策略">
            <Select v-model="form.concurrent">
              <SelectTrigger><SelectValue placeholder="请选择并发策略" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="0">允许并发</SelectItem>
                <SelectItem value="1">禁止并发</SelectItem>
              </SelectContent>
            </Select>
          </AdminFormField>
          <AdminFormField label="备注" field-class="md:col-span-2">
            <Textarea v-model="form.remark" class="min-h-28" placeholder="请输入备注" />
          </AdminFormField>
        </div>

        <DialogFooter>
          <Button variant="outline" @click="formOpen = false">取消</Button>
          <Button :disabled="submitting" @click="submitForm">{{ submitting ? '提交中...' : '提交' }}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </div>
</template>


