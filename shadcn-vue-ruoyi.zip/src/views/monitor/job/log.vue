<script setup lang="ts">
import { computed, onMounted, reactive, ref } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { toast } from 'vue-sonner'

import type { AdminTableColumn } from '@/components/admin/data-table'

import { getJob } from '@/api/monitor/job'
import { cleanJobLog, delJobLog, exportJobLog, listJobLog } from '@/api/monitor/jobLog'
import AdminDataTable from '@/components/admin/AdminDataTable.vue'
import AdminFormField from '@/components/admin/AdminFormField.vue'
import AdminQueryPanel from '@/components/admin/AdminQueryPanel.vue'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useAccess } from '@/lib/access'
import { saveBlob } from '@/lib/download'
import { permissionKeys } from '@/lib/permission-keys'
import { prettyJson } from '@/lib/monitor'

const route = useRoute()
const router = useRouter()
const access = useAccess()
const jobPerms = permissionKeys.monitor.job

const jobLogColumns: AdminTableColumn[] = [
  { key: 'jobLogId', title: '日志编号' },
  { key: 'jobName', title: '任务名称' },
  { key: 'jobGroup', title: '任务组名' },
  { key: 'invokeTarget', title: '调用目标' },
  { key: 'jobMessage', title: '日志信息' },
  { key: 'status', title: '结果' },
  { key: 'createTime', title: '执行时间' },
]

const loading = ref(false)
const rows = ref<any[]>([])
const total = ref(0)
const currentJobName = ref('调度日志')
const currentJobGroup = ref('')
const detailOpen = ref(false)
const detailRow = ref<Record<string, any> | null>(null)

const queryParams = reactive({
  pageNum: 1,
  pageSize: 10,
  jobName: '',
  status: 'all',
})

const canQueryJobLog = computed(() => access.can(jobPerms.query))
const canRemoveJobLog = computed(() => access.can(jobPerms.remove))
const canExportJobLog = computed(() => access.can(jobPerms.export))
const showJobLogActions = computed(() => canQueryJobLog.value || canRemoveJobLog.value)
const detailText = computed(() => prettyJson(detailRow.value))

function statusText(value: string) {
  return value === '0' ? '成功' : '失败'
}

function buildQueryPayload() {
  return {
    jobName: queryParams.jobName || undefined,
    jobGroup: currentJobGroup.value || undefined,
    status: queryParams.status === 'all' ? undefined : queryParams.status,
  }
}

async function loadContext() {
  const jobId = String(route.params.jobId ?? '')
  if (!jobId || jobId === '0') {
    return
  }
  try {
    const response = await getJob(jobId)
    currentJobName.value = String(response.data?.jobName ?? '调度日志')
    currentJobGroup.value = String(response.data?.jobGroup ?? '')
    queryParams.jobName = currentJobName.value === '调度日志' ? '' : currentJobName.value
  }
  catch (error) {
    toast.error('任务上下文加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function loadList() {
  loading.value = true
  try {
    const response = await listJobLog({
      pageNum: queryParams.pageNum,
      pageSize: queryParams.pageSize,
      ...buildQueryPayload(),
    })
    rows.value = Array.isArray(response.rows) ? response.rows : []
    total.value = Number(response.total ?? 0)
  }
  catch (error) {
    toast.error('调度日志加载失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
  finally {
    loading.value = false
  }
}

async function handleQuery() {
  queryParams.pageNum = 1
  await loadList()
}

async function handleResetQuery() {
  queryParams.pageNum = 1
  queryParams.pageSize = 10
  queryParams.jobName = currentJobName.value === '调度日志' ? '' : currentJobName.value
  queryParams.status = 'all'
  await loadList()
}

async function handleExport() {
  if (!access.require(jobPerms.export, '导出调度日志')) {
    return
  }

  try {
    const blob = await exportJobLog(buildQueryPayload())
    saveBlob(blob, 'jobLog.xlsx')
    toast.success('调度日志已开始导出')
  }
  catch (error) {
    toast.error('调度日志导出失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

function openDetail(row: Record<string, any>) {
  if (!access.require(jobPerms.query, '查看调度日志详情')) {
    return
  }
  detailRow.value = row
  detailOpen.value = true
}

async function removeRow(row: Record<string, any>) {
  if (!access.require(jobPerms.remove, '删除调度日志')) {
    return
  }

  try {
    await delJobLog(row.jobLogId)
    toast.success('日志删除成功')
    await loadList()
  }
  catch (error) {
    toast.error('日志删除失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function clearLogs() {
  if (!access.require(jobPerms.remove, '清空调度日志')) {
    return
  }

  try {
    await cleanJobLog()
    toast.success('日志清空成功')
    await loadList()
  }
  catch (error) {
    toast.error('日志清空失败', { description: error instanceof Error ? error.message : '请稍后重试。' })
  }
}

async function changePage(step: number) {
  const nextPage = queryParams.pageNum + step
  if (nextPage < 1) {
    return
  }
  queryParams.pageNum = nextPage
  await loadList()
}

async function changePageSize(value: number) {
  queryParams.pageNum = 1
  queryParams.pageSize = value
  await loadList()
}

onMounted(async () => {
  await loadContext()
  await loadList()
})
</script>

<template>
  <div class="space-y-6">
    <div class="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
      <div>
        <p class="text-xs uppercase tracking-[0.24em] text-muted-foreground">系统监控 / 调度日志</p>
        <h1 class="mt-2 text-3xl font-semibold tracking-tight">{{ currentJobName }}</h1>
        <p class="mt-2 max-w-3xl text-sm leading-6 text-muted-foreground">调度日志页已经切成真实分页列表，当前任务组为 {{ currentJobGroup || '--' }}。</p>
      </div>
      <div class="flex flex-wrap gap-2">
        <Button variant="outline" @click="router.push('/monitor/job')">返回任务列表</Button>
        <Button v-if="canExportJobLog" variant="outline" @click="handleExport">导出日志</Button>
        <Button v-if="canRemoveJobLog" variant="outline" @click="clearLogs">清空日志</Button>
        <Button variant="outline" @click="loadList">刷新列表</Button>
      </div>
    </div>

    <AdminQueryPanel description="任务名称和执行结果直接作用于真实调度日志接口。" @query="handleQuery" @reset="handleResetQuery">
      <AdminFormField label="任务名称">
        <Input v-model="queryParams.jobName" placeholder="请输入任务名称" />
      </AdminFormField>
      <AdminFormField label="执行结果">
        <Select v-model="queryParams.status">
          <SelectTrigger><SelectValue placeholder="请选择执行结果" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部</SelectItem>
            <SelectItem value="0">成功</SelectItem>
            <SelectItem value="1">失败</SelectItem>
          </SelectContent>
        </Select>
      </AdminFormField>
    </AdminQueryPanel>

    <AdminSectionCard title="调度日志列表" description="支持日志分页、详情查看、删除和导出。">
      <AdminDataTable
        :columns="jobLogColumns"
        :rows="rows"
        row-key="jobLogId"
        :loading="loading"
        loading-text="正在加载调度日志..."
        empty-text="暂无数据"
        :show-actions="showJobLogActions"
        action-header-class="w-[220px] text-right"
        :show-pagination="true"
        :total="total"
        :page-num="queryParams.pageNum"
        :page-size="queryParams.pageSize"
        @update:page-size="changePageSize"
        @previous="changePage(-1)"
        @next="changePage(1)"
      >
        <template #cell-jobName="{ value }">
          <span class="font-medium">{{ value }}</span>
        </template>
        <template #cell-status="{ row }">
          <Badge variant="outline">{{ statusText(String(row.status ?? '0')) }}</Badge>
        </template>
        <template #actions="{ row }">
          <div class="flex flex-wrap justify-end gap-2">
            <Button v-if="canQueryJobLog" size="sm" variant="outline" @click="openDetail(row)">详情</Button>
            <Button v-if="canRemoveJobLog" size="sm" variant="destructive" @click="removeRow(row)">删除</Button>
          </div>
        </template>
      </AdminDataTable>
    </AdminSectionCard>

    <Dialog v-model:open="detailOpen">
      <DialogContent class="sm:max-w-[900px]">
        <DialogHeader>
          <DialogTitle>调度日志详情</DialogTitle>
          <DialogDescription>展示当前日志行的真实返回内容，便于排查任务执行结果。</DialogDescription>
        </DialogHeader>

        <div class="grid gap-4 md:grid-cols-2">
          <div class="rounded-3xl border border-border/70 bg-muted/20 p-4">
            <p class="text-xs uppercase tracking-[0.2em] text-muted-foreground">基础信息</p>
            <div class="mt-3 space-y-3 text-sm">
              <div class="flex justify-between gap-4"><span class="text-muted-foreground">日志编号</span><span class="text-right font-medium">{{ detailRow?.jobLogId ?? '--' }}</span></div>
              <div class="flex justify-between gap-4"><span class="text-muted-foreground">任务名称</span><span class="text-right font-medium">{{ detailRow?.jobName ?? '--' }}</span></div>
              <div class="flex justify-between gap-4"><span class="text-muted-foreground">任务组</span><span class="text-right font-medium">{{ detailRow?.jobGroup ?? '--' }}</span></div>
              <div class="flex justify-between gap-4"><span class="text-muted-foreground">调用目标</span><span class="break-all text-right font-medium">{{ detailRow?.invokeTarget ?? '--' }}</span></div>
              <div class="flex justify-between gap-4"><span class="text-muted-foreground">执行结果</span><span class="text-right font-medium">{{ statusText(String(detailRow?.status ?? '0')) }}</span></div>
              <div class="flex justify-between gap-4"><span class="text-muted-foreground">执行时间</span><span class="text-right font-medium">{{ detailRow?.createTime ?? '--' }}</span></div>
            </div>
          </div>

          <div class="rounded-3xl border border-border/70 bg-muted/20 p-4">
            <p class="text-xs uppercase tracking-[0.2em] text-muted-foreground">日志信息</p>
            <pre class="mt-3 min-h-[220px] overflow-x-auto whitespace-pre-wrap font-mono text-xs leading-6 text-foreground">{{ detailText }}</pre>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" @click="detailOpen = false">关闭</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  </div>
</template>

