<script setup lang="ts">
import { Command as CommandIcon, LockKeyhole, LogOut, RefreshCw, UserRound } from 'lucide-vue-next'
import { computed } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'

import NoticeCenter from '@/components/app/NoticeCenter.vue'
import ThemeToggle from '@/components/app/ThemeToggle.vue'
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '@/components/ui/breadcrumb'
import { Button } from '@/components/ui/button'
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Separator } from '@/components/ui/separator'
import { SidebarTrigger } from '@/components/ui/sidebar'
import { resolveIcon } from '@/lib/icons'
import { useNavigationStore } from '@/stores/navigation'
import { useSessionStore } from '@/stores/session'
import { useUiStore } from '@/stores/ui'

const router = useRouter()
const route = useRoute()
const session = useSessionStore()
const ui = useUiStore()
const navigation = useNavigationStore()

const activeMenu = computed(() => String(route.meta.activeMenu ?? route.path))
const group = computed(() => navigation.findGroup(activeMenu.value))
const navItem = computed(() => navigation.findItem(activeMenu.value))
const commandEntries = computed(() => [...navigation.allItems, ...navigation.quickActions])

const breadcrumbItems = computed(() => {
  const items: string[] = []
  if (group.value) {
    items.push(group.value.title)
  }
  if (navItem.value) {
    items.push(navItem.value.title)
  }
  const routeTitle = String(route.meta.title ?? '')
  if (route.meta.hidden && routeTitle) {
    items.push(routeTitle)
  }
  return items
})

function navigate(path: string) {
  ui.setCommandOpen(false)
  router.push(path)
}

function refreshCurrentRoute() {
  const normalizedPath = route.path.replace(/^\/+/, '')
  const redirectPath = normalizedPath ? `/redirect/${normalizedPath}` : '/redirect/index'
  router.replace({
    path: redirectPath,
    query: route.query,
    hash: route.hash,
  })
}

async function logout() {
  await session.logout()
  ui.resetTags()
  router.push('/login')
}

function lockScreen() {
  session.lock()
  router.push('/lock')
}
</script>

<template>
  <header class="sticky top-0 z-30 border-b border-border/40 bg-background/60 shadow-sm backdrop-blur-2xl transition-all">
    <div class="mx-auto flex h-16 max-w-[1600px] items-center gap-3 px-4 md:px-6">
      <SidebarTrigger class="-ml-1" />
      <Separator orientation="vertical" class="h-5" />

      <div class="min-w-0">
        <Breadcrumb>
          <BreadcrumbList>
            <BreadcrumbItem>
              <BreadcrumbLink as-child>
                <RouterLink to="/index">工作台</RouterLink>
              </BreadcrumbLink>
            </BreadcrumbItem>
            <template v-for="(item, index) in breadcrumbItems" :key="`${item}-${index}`">
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{{ item }}</BreadcrumbPage>
              </BreadcrumbItem>
            </template>
          </BreadcrumbList>
        </Breadcrumb>
        <p class="truncate text-xs text-muted-foreground">{{ route.meta.title }}</p>
      </div>

      <div class="ml-auto flex items-center gap-2">
        <Button variant="outline" size="icon" @click="refreshCurrentRoute">
          <RefreshCw class="size-4" />
          <span class="sr-only">刷新当前页</span>
        </Button>
        <Button variant="outline" class="hidden md:flex" @click="ui.setCommandOpen(true)">
          <CommandIcon class="mr-2 size-4" />
          搜索菜单
        </Button>
        <ThemeToggle />
        <NoticeCenter />
        <DropdownMenu>
          <DropdownMenuTrigger as-child>
            <Button variant="outline" class="px-3">
              <UserRound class="mr-2 size-4" />
              {{ session.user.name }}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" class="w-56">
            <DropdownMenuItem @select.prevent="router.push('/user/profile')">
              <UserRound class="size-4" />
              个人中心
            </DropdownMenuItem>
            <DropdownMenuItem @select.prevent="lockScreen">
              <LockKeyhole class="size-4" />
              锁屏
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem variant="destructive" @select.prevent="logout">
              <LogOut class="size-4" />
              退出登录
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  </header>

  <CommandDialog :open="ui.commandOpen" @update:open="ui.setCommandOpen">
    <CommandInput placeholder="搜索菜单、页面或快捷入口..." />
    <CommandList>
      <CommandEmpty>没有匹配的菜单。</CommandEmpty>
      <CommandGroup heading="菜单导航">
        <CommandItem
          v-for="item in commandEntries"
          :key="item.path"
          :value="item.title"
          @select="navigate(item.path)"
        >
          <component :is="resolveIcon(item.icon)" class="mr-2 size-4" />
          <span>{{ item.title }}</span>
        </CommandItem>
      </CommandGroup>
    </CommandList>
  </CommandDialog>
</template>
