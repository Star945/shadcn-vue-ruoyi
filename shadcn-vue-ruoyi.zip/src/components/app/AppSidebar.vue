﻿<script setup lang="ts">
import { computed } from 'vue'
import { RouterLink, useRoute } from 'vue-router'

import { resolveIcon } from '@/lib/icons'
import { useNavigationStore } from '@/stores/navigation'
import { useSessionStore } from '@/stores/session'
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
} from '@/components/ui/sidebar'

const route = useRoute()
const session = useSessionStore()
const navigation = useNavigationStore()

const activePath = computed(() => String(route.meta.activeMenu ?? route.path))
const groups = computed(() => navigation.groups)
const quickActions = computed(() => navigation.quickActions)
</script>

<template>
  <Sidebar collapsible="icon" variant="inset">
    <SidebarHeader>
      <SidebarMenu>
        <SidebarMenuItem>
          <SidebarMenuButton
            as-child
            size="lg"
            class="bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90 hover:text-sidebar-primary-foreground"
          >
            <RouterLink to="/index">
              <div class="flex aspect-square size-8 items-center justify-center rounded-xl bg-white/15">
                <component :is="resolveIcon('sparkles')" class="size-4" />
              </div>
              <div class="grid flex-1 text-left text-sm leading-tight">
                <span class="truncate font-semibold">RuoYi Modern 后台</span>
                <span class="truncate text-xs opacity-80">Vue 3 管理后台</span>
              </div>
            </RouterLink>
          </SidebarMenuButton>
        </SidebarMenuItem>
      </SidebarMenu>
    </SidebarHeader>

    <SidebarContent>
      <SidebarGroup v-for="group in groups" :key="group.title">
        <SidebarGroupLabel>{{ group.title }}</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
            <SidebarMenuItem v-for="item in group.items" :key="item.path">
              <SidebarMenuButton as-child :is-active="activePath === item.path" :tooltip="item.title">
                <RouterLink :to="item.path">
                  <component :is="resolveIcon(item.icon)" />
                  <span>{{ item.title }}</span>
                </RouterLink>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
    </SidebarContent>

    <SidebarFooter>
      <SidebarGroup>
        <SidebarGroupLabel>快捷入口</SidebarGroupLabel>
        <SidebarGroupContent>
          <SidebarMenu>
            <SidebarMenuItem v-for="item in quickActions" :key="item.path">
              <SidebarMenuButton as-child :tooltip="item.title">
                <RouterLink :to="item.path">
                  <component :is="resolveIcon(item.icon)" />
                  <span>{{ item.title }}</span>
                </RouterLink>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroupContent>
      </SidebarGroup>
      <SidebarSeparator />
      <div class="rounded-2xl border border-sidebar-border/70 bg-sidebar-accent/50 p-3 group-data-[collapsible=icon]:hidden">
        <p class="text-xs uppercase tracking-[0.24em] text-sidebar-foreground/60">当前用户</p>
        <p class="mt-2 text-sm font-semibold text-sidebar-foreground">{{ session.user.name }}</p>
        <p class="text-xs text-sidebar-foreground/70">{{ session.user.role }} · {{ session.user.dept }}</p>
      </div>
    </SidebarFooter>

    <SidebarRail />
  </Sidebar>
</template>

