<script setup lang="ts">
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import AdminSectionCard from '@/components/admin/AdminSectionCard.vue'

const props = withDefaults(defineProps<{
  title?: string
  description?: string
  gridClass?: string
  queryText?: string
  resetText?: string
}>(), {
  title: '查询条件',
  description: '',
  gridClass: 'md:grid-cols-2 xl:grid-cols-4',
  queryText: '查询',
  resetText: '重置',
})

const emit = defineEmits<{
  (e: 'query'): void
  (e: 'reset'): void
}>()
</script>

<template>
  <AdminSectionCard :title="title" :description="description" content-class="space-y-4">
    <div :class="cn('grid gap-4', props.gridClass)">
      <slot />
    </div>
    <div class="flex flex-wrap gap-2">
      <slot name="actions">
        <Button @click="emit('query')">{{ queryText }}</Button>
        <Button variant="outline" @click="emit('reset')">{{ resetText }}</Button>
      </slot>
    </div>
  </AdminSectionCard>
</template>
