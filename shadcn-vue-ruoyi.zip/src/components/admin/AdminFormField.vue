﻿<script setup lang="ts">
import { cn } from '@/lib/utils'

withDefaults(defineProps<{
  label: string
  fieldClass?: string
  labelClass?: string
  contentClass?: string
}>(), {
  fieldClass: '',
  labelClass: '',
  contentClass: '',
})
</script>

<template>
  <div :class="cn('space-y-2', fieldClass)">
    <p :class="cn('text-sm font-medium', labelClass)">{{ label }}</p>
    <div :class="contentClass">
      <slot />
    </div>
  </div>
</template>
