<script setup lang="ts">
import { computed, useSlots } from 'vue'

import type { AdminTableColumn } from '@/components/admin/data-table'

import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Checkbox } from '@/components/ui/checkbox'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableEmpty, TableHead, TableHeader, TableRow } from '@/components/ui/table'

const props = withDefaults(defineProps<{
  columns: AdminTableColumn[]
  rows: Array<Record<string, any>>
  rowKey?: string | ((row: Record<string, any>, index: number) => string | number)
  loading?: boolean
  loadingText?: string
  emptyText?: string
  showSelection?: boolean
  selectedRowKeys?: Array<string | number>
  selectionHeaderClass?: string
  selectionCellClass?: string
  showActions?: boolean
  actionHeader?: string
  actionHeaderClass?: string
  actionCellClass?: string
  showPagination?: boolean
  total?: number
  pageNum?: number
  pageSize?: number
  pageSizeOptions?: number[]
  previousDisabled?: boolean
  nextDisabled?: boolean
}>(), {
  rowKey: 'id',
  loading: false,
  loadingText: '正在加载数据...',
  emptyText: '暂无数据',
  showSelection: false,
  selectedRowKeys: () => [],
  selectionHeaderClass: 'w-12',
  selectionCellClass: '',
  showActions: false,
  actionHeader: '操作',
  actionHeaderClass: 'w-[240px] text-right',
  actionCellClass: 'text-right',
  showPagination: false,
  total: 0,
  pageNum: 1,
  pageSize: 10,
  pageSizeOptions: () => [10, 20, 50],
  previousDisabled: undefined,
  nextDisabled: undefined,
})

const emit = defineEmits<{
  (e: 'previous'): void
  (e: 'next'): void
  (e: 'update:pageSize', value: number): void
  (e: 'update:selectedRowKeys', value: Array<string | number>): void
  (e: 'selectionChange', rows: Array<Record<string, any>>, keys: Array<string | number>): void
}>()

const slots = useSlots()
const withSelection = computed(() => props.showSelection || Boolean(slots.selection) || Boolean(slots['selection-header']))
const withActions = computed(() => props.showActions || Boolean(slots.actions))
const totalColumns = computed(() => props.columns.length + (withSelection.value ? 1 : 0) + (withActions.value ? 1 : 0))
const selectedKeySet = computed(() => new Set(props.selectedRowKeys))
const previousButtonDisabled = computed(() => props.previousDisabled ?? props.pageNum <= 1)
const nextButtonDisabled = computed(() => {
  if (typeof props.nextDisabled === 'boolean') {
    return props.nextDisabled
  }
  if (props.total > 0) {
    return props.pageNum * props.pageSize >= props.total
  }
  return props.rows.length < props.pageSize
})
const allVisibleSelected = computed(() => props.rows.length > 0 && props.rows.every((row, index) => selectedKeySet.value.has(resolveRowKey(row, index))))
const someVisibleSelected = computed(() => !allVisibleSelected.value && props.rows.some((row, index) => selectedKeySet.value.has(resolveRowKey(row, index))))

function resolveRowKey(row: Record<string, any>, index: number) {
  if (typeof props.rowKey === 'function') {
    return props.rowKey(row, index)
  }
  if (props.rowKey && row[props.rowKey] !== undefined && row[props.rowKey] !== null) {
    return row[props.rowKey]
  }
  return row.id ?? index
}

function cellValue(row: Record<string, any>, key: string) {
  const directValue = row[key]
  if (directValue !== undefined) {
    return directValue === null || directValue === '' ? '--' : directValue
  }
  const rawValue = row.raw?.[key]
  return rawValue === undefined || rawValue === null || rawValue === '' ? '--' : rawValue
}

function updatePageSize(value: unknown) {
  const nextSize = Number(value ?? props.pageSize)
  emit('update:pageSize', Number.isFinite(nextSize) && nextSize > 0 ? nextSize : props.pageSize)
}

function syncSelection(nextKeys: Array<string | number>) {
  emit('update:selectedRowKeys', nextKeys)
  const selectedRows = props.rows.filter((row, index) => nextKeys.includes(resolveRowKey(row, index)))
  emit('selectionChange', selectedRows, nextKeys)
}

function toggleAllSelection(checked: boolean | 'indeterminate') {
  if (!Boolean(checked)) {
    const visibleKeys = props.rows.map((row, index) => resolveRowKey(row, index))
    syncSelection(props.selectedRowKeys.filter(key => !visibleKeys.includes(key)))
    return
  }

  const nextKeys = [...props.selectedRowKeys]
  props.rows.forEach((row, index) => {
    const key = resolveRowKey(row, index)
    if (!nextKeys.includes(key)) {
      nextKeys.push(key)
    }
  })
  syncSelection(nextKeys)
}

function toggleRowSelection(row: Record<string, any>, index: number, checked: boolean | 'indeterminate') {
  const key = resolveRowKey(row, index)
  if (Boolean(checked)) {
    if (!props.selectedRowKeys.includes(key)) {
      syncSelection([...props.selectedRowKeys, key])
    }
    return
  }
  syncSelection(props.selectedRowKeys.filter(selectedKey => selectedKey !== key))
}
</script>

<template>
  <div>
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead v-if="withSelection" :class="selectionHeaderClass">
            <slot name="selection-header">
              <Checkbox
                :checked="allVisibleSelected ? true : someVisibleSelected ? 'indeterminate' : false"
                @update:checked="toggleAllSelection"
              />
            </slot>
          </TableHead>
          <TableHead v-for="column in columns" :key="column.key" :class="column.headerClass">{{ column.title }}</TableHead>
          <TableHead v-if="withActions" :class="actionHeaderClass">{{ actionHeader }}</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        <TableEmpty v-if="loading" :colspan="totalColumns" class="text-muted-foreground">{{ loadingText }}</TableEmpty>
        <TableEmpty v-else-if="!rows.length" :colspan="totalColumns" class="text-muted-foreground">{{ emptyText }}</TableEmpty>
        <TableRow v-for="(row, index) in rows" v-else :key="resolveRowKey(row, index)">
          <TableCell v-if="withSelection" :class="selectionCellClass">
            <slot name="selection" :row="row" :index="index">
              <Checkbox
                :checked="selectedKeySet.has(resolveRowKey(row, index))"
                @update:checked="(checked: boolean | 'indeterminate') => toggleRowSelection(row, index, checked)"
              />
            </slot>
          </TableCell>
          <TableCell v-for="column in columns" :key="column.key" :class="column.cellClass">
            <slot :name="`cell-${column.key}`" :row="row" :index="index" :column="column" :value="cellValue(row, column.key)">
              {{ cellValue(row, column.key) }}
            </slot>
          </TableCell>
          <TableCell v-if="withActions" :class="cn('align-middle', actionCellClass)">
            <slot name="actions" :row="row" :index="index" />
          </TableCell>
        </TableRow>
      </TableBody>
    </Table>

    <div v-if="showPagination" class="mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div class="flex items-center gap-2 text-sm text-muted-foreground">
        <span>共 {{ total }} 条</span>
        <Select :model-value="String(pageSize)" @update:model-value="updatePageSize">
          <SelectTrigger class="h-9 w-24"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem v-for="option in pageSizeOptions" :key="option" :value="String(option)">{{ option }} / 页</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div class="flex items-center justify-end gap-2">
        <Button variant="outline" :disabled="previousButtonDisabled" @click="emit('previous')">上一页</Button>
        <Badge variant="outline">第 {{ pageNum }} 页</Badge>
        <Button variant="outline" :disabled="nextButtonDisabled" @click="emit('next')">下一页</Button>
      </div>
    </div>
  </div>
</template>

