﻿export interface AdminTableColumn {
  key: string
  title: string
  headerClass?: string
  cellClass?: string
}
